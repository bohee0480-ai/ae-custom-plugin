/* Lucide icons — inline SVG for CEP (no network) */
var LucideIcons = (function () {
    "use strict";

    function svg(name, paths, size) {
        size = size || 18;
        return (
            '<svg xmlns="http://www.w3.org/2000/svg" width="' + size + '" height="' + size + '" ' +
            'viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" ' +
            'stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' +
            paths + "</svg>"
        );
    }

    var icons = {
        pencil: svg("pencil",
            '<path d="M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z"/>' +
            '<path d="m15 5 4 4"/>'),
        undo2: svg("undo2",
            '<path d="M9 14 4 9l5-5"/>' +
            '<path d="M4 9h10.5a5.5 5.5 0 0 1 5.5 5.5v0a5.5 5.5 0 0 1-5.5 5.5H11"/>'),
        trash2: svg("trash2",
            '<path d="M3 6h18"/>' +
            '<path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/>' +
            '<path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/>' +
            '<line x1="10" x2="10" y1="11" y2="17"/>' +
            '<line x1="14" x2="14" y1="11" y2="17"/>'),
        layers: svg("layers",
            '<path d="m12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83Z"/>' +
            '<path d="m22 17.65-9.17 4.16a2 2 0 0 1-1.66 0L2 17.65"/>' +
            '<path d="m22 12.65-9.17 4.16a2 2 0 0 1-1.66 0L2 12.65"/>'),
        minus: svg("minus", '<path d="M5 12h14"/>'),
        plus: svg("plus", '<path d="M5 12h14"/><path d="M12 5v14"/>'),
        wind: svg("wind",
            '<path d="M17.7 7.7a2.5 2.5 0 1 1 1.8 4.3H2"/>' +
            '<path d="M9.6 4.6A2 2 0 1 1 11 8H2"/>' +
            '<path d="M12.6 19.4A2 2 0 1 0 14 16H2"/>'),
        trendingUp: svg("trendingUp",
            '<polyline points="22 7 13.5 15.5 8.5 10.5 2 17"/>' +
            '<polyline points="16 7 22 7 22 13"/>'),
        activity: svg("activity", '<path d="M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.49 12H2"/>'),
        waves: svg("waves",
            '<path d="M2 6c.6.5 1.2 1 2.5 1C7 7 7 5 9.5 5c2.6 0 2.4 2 5 2 2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1"/>' +
            '<path d="M2 12c.6.5 1.2 1 2.5 1 2.5 0 2.5-2 5-2 2.6 0 2.4 2 5 2 2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1"/>' +
            '<path d="M2 18c.6.5 1.2 1 2.5 1 2.5 0 2.5-2 5-2 2.6 0 2.4 2 5 2 2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1"/>'),
        palette: svg("palette",
            '<circle cx="13.5" cy="6.5" r=".5" fill="currentColor"/>' +
            '<circle cx="17.5" cy="10.5" r=".5" fill="currentColor"/>' +
            '<circle cx="8.5" cy="7.5" r=".5" fill="currentColor"/>' +
            '<circle cx="6.5" cy="12.5" r=".5" fill="currentColor"/>' +
            '<path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.926 0 1.648-.746 1.648-1.688 0-.437-.18-.835-.437-1.125-.29-.289-.438-.652-.438-1.125a1.64 1.64 0 0 1 1.668-1.668h1.996c3.051 0 5.555-2.503 5.555-5.554C21.965 6.012 17.461 2 12 2z"/>'),
        grid3x3: svg("grid3x3",
            '<rect width="18" height="18" x="3" y="3" rx="2"/>' +
            '<path d="M3 9h18"/>' +
            '<path d="M3 15h18"/>' +
            '<path d="M9 3v18"/>' +
            '<path d="M15 3v18"/>'),
        circle: svg("circle", '<circle cx="12" cy="12" r="10"/>'),
        checkSquare: svg("checkSquare",
            '<path d="m9 11 3 3 8-8"/>' +
            '<path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/>'),
        square: svg("square", '<rect width="18" height="18" x="3" y="3" rx="2"/>'),
        sparkles: svg("sparkles",
            '<path d="M9.937 15.5A2 2 0 0 0 8.5 14.063l-6.135-1.582a.5.5 0 0 1 0-.962L8.5 9.936A2 2 0 0 0 9.937 8.5l1.582-6.135a.5.5 0 0 1 .963 0L14.063 8.5A2 2 0 0 0 15.5 9.937l6.135 1.581a.5.5 0 0 1 0 .964L15.5 14.063a2 2 0 0 0-1.437 1.437l-1.582 6.135a.5.5 0 0 1-.963 0z"/>' +
            '<path d="M20 3v4"/><path d="M22 5h-4"/><path d="M4 17v2"/><path d="M5 18H3"/>'),
        logIn: svg("logIn",
            '<path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"/>' +
            '<polyline points="10 17 15 12 10 7"/>' +
            '<line x1="15" x2="3" y1="12" y2="12"/>'),
        logOut: svg("logOut",
            '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/>' +
            '<polyline points="16 17 21 12 16 7"/>' +
            '<line x1="21" x2="9" y1="12" y2="12"/>'),
        zap: svg("zap", '<path d="M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13.6 11H20a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 10.4 14z"/>'),
        magnet: svg("magnet",
            '<path d="m6 15-4-4"/><path d="m6 15 4 4"/>' +
            '<path d="m6 15 4-4"/><path d="m6 15-4 4"/>' +
            '<path d="M10.5 8.5 8 6c-2.2-2.2-5.7-2.2-7.9 0s-2.2 5.7 0 7.9l2.5 2.5"/>' +
            '<path d="M13.5 11.5 16 14c2.2 2.2 5.7 2.2 7.9 0s2.2-5.7 0-7.9l-2.5-2.5"/>'),
        moveHorizontal: svg("moveHorizontal",
            '<polyline points="18 8 22 12 18 16"/>' +
            '<polyline points="6 8 2 12 6 16"/>' +
            '<line x1="2" x2="22" y1="12" y2="12"/>'),
        pause: svg("pause", '<rect x="14" y="4" width="4" height="16" rx="1"/><rect x="6" y="4" width="4" height="16" rx="1"/>'),
        cornerDownRight: svg("cornerDownRight",
            '<polyline points="15 10 20 15 15 20"/>' +
            '<path d="M4 4v7a4 4 0 0 0 4 4h12"/>'),
        cornerUpRight: svg("cornerUpRight",
            '<polyline points="15 14 20 9 15 4"/>' +
            '<path d="M4 20v-7a4 4 0 0 1 4-4h12"/>'),
        arrowBigDown: svg("arrowBigDown",
            '<path d="M15 11a1 1 0 0 0 1 1h2.939a1 1 0 0 1 .751 1.659l-6.005 6.912a1.1 1.1 0 0 1-1.65 0l-6.005-6.912A1 1 0 0 1 6.06 12H9a1 1 0 0 0 1-1V5a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1z"/>'),
        gitMerge: svg("gitMerge",
            '<circle cx="18" cy="18" r="3"/>' +
            '<circle cx="6" cy="6" r="3"/>' +
            '<circle cx="6" cy="18" r="3"/>' +
            '<path d="M6 9v6a3 3 0 0 0 3 3h9"/>'),
        squircle: svg("squircle",
            '<rect width="18" height="18" x="3" y="3" rx="6"/>'),
        star: svg("star",
            '<polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>'),
        triangle: svg("triangle",
            '<path d="M12 3 22 20H2z"/>'),
        shuffle: svg("shuffle",
            '<path d="m18 14 4 4-4 4"/>' +
            '<path d="m18 2 4 4-4 4"/>' +
            '<path d="M2 18h1.973a4 4 0 0 0 3.3-1.7l5.454-8.6a4 4 0 0 1 3.3-1.7H22"/>' +
            '<path d="M2 6h1.972a4 4 0 0 1 3.6 2.2"/>' +
            '<path d="M22 18h-6.041a4 4 0 0 1-3.3-1.8L7.24 7.8"/>'),
        expand: svg("expand",
            '<path d="m21 21-6-6m6 6v-4.8m0 4.8h-4.8"/>' +
            '<path d="M3 16.2V21m0 0h4.8M3 21l6-6"/>' +
            '<path d="M21 7.8V3m0 0h-4.8M21 3l-6 6"/>' +
            '<path d="M3 7.8V3m0 0h4.8M3 3l6 6"/>'),
        shrink: svg("shrink",
            '<path d="m15 9 6-6"/>' +
            '<path d="M21 9h-6V3"/>' +
            '<path d="m3 15 6 6"/>' +
            '<path d="M9 15H3v6"/>' +
            '<path d="m21 15-6 6"/>' +
            '<path d="M15 15h6v6"/>' +
            '<path d="m3 9 6-6"/>' +
            '<path d="M3 9h6V3"/>'),
        search: svg("search",
            '<circle cx="11" cy="11" r="8"/>' +
            '<path d="m21 21-4.3-4.3"/>'),
        x: svg("x", '<path d="M18 6 6 18"/><path d="m6 6 12 12"/>')
    };

    function mount(el, iconName, size) {
        if (!el || !icons[iconName]) return;
        el.innerHTML = icons[iconName].replace(/width="\d+"/, 'width="' + (size || 18) + '"').replace(/height="\d+"/, 'height="' + (size || 18) + '"');
    }

    return { icons: icons, mount: mount };
}());
