#!/bin/bash
set -e
ID="com.muelmu3kism.motion-control"
HERE="$(cd "$(dirname "$0")" && pwd)"
SRC="$HERE/extension/$ID"
DEST="$HOME/Library/Application Support/Adobe/CEP/extensions/$ID"

if [ ! -f "$SRC/CSXS/manifest.xml" ]; then
  echo "설치 파일을 찾지 못했습니다. ZIP을 먼저 완전히 풀어 주세요."
  read -r
  exit 1
fi

mkdir -p "$(dirname "$DEST")"
rm -rf "$DEST"
cp -R "$SRC" "$DEST"
printf "motion-control-public" > "$DEST/.debug"
defaults write com.adobe.CSXS.10 PlayerDebugMode 1
defaults write com.adobe.CSXS.11 PlayerDebugMode 1
defaults write com.adobe.CSXS.12 PlayerDebugMode 1

echo ""
echo "설치 완료!"
echo "After Effects를 완전히 종료한 뒤 다시 실행하세요."
echo "창 > 확장 기능(레거시) > Motion Control을 여세요."
read -r