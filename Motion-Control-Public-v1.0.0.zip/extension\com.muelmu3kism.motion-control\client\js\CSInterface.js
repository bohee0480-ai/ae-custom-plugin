/**
 * CSInterface.js — minimal subset for Draw and Easing Panel
 * Based on Adobe CEP 11.x CSInterface
 */
(function (root, factory) {
    if (typeof module === "object" && module.exports) {
        module.exports = factory();
    } else {
        root.CSInterface = factory();
    }
}(this, function () {
    function CSInterface() {}

    CSInterface.prototype.getSystemPath = function (pathType) {
        var path = window.__adobe_cep__.getSystemPath(pathType);
        if (!path) return "";
        try {
            path = decodeURI(path);
        } catch (e0) {}
        // CEP panels have no Node "process" — strip file:// on all platforms
        if (path.indexOf("file://") === 0) {
            path = path.replace(/^file:\/{2,3}/, "");
            path = path.replace(/^file:\/\//, "");
        }
        return path;
    };

    CSInterface.prototype.evalScript = function (script, callback) {
        if (callback === null || callback === undefined) {
            callback = function () {};
        }
        window.__adobe_cep__.evalScript(script, callback);
    };

    CSInterface.prototype.getHostEnvironment = function () {
        var hostEnv = window.__adobe_cep__.getHostEnvironment();
        return JSON.parse(hostEnv);
    };

    CSInterface.prototype.addEventListener = function (type, listener, obj) {
        window.__adobe_cep__.addEventListener(type, listener, obj);
    };

    CSInterface.prototype.dispatchEvent = function (event) {
        if (typeof event.data === "object") {
            event.data = JSON.stringify(event.data);
        }
        window.__adobe_cep__.dispatchEvent(event);
    };

    CSInterface.prototype.getExtensionID = function () {
        return window.__adobe_cep__.getExtensionId();
    };

    CSInterface.prototype.openURLInDefaultBrowser = function (url) {
        window.cep.util.openURLInDefaultBrowser(url);
    };

    CSInterface.prototype.getApplicationID = function () {
        var hostEnv = this.getHostEnvironment();
        return hostEnv.appId;
    };

    CSInterface.prototype.getHostCapabilities = function () {
        return JSON.parse(window.__adobe_cep__.getHostCapabilities());
    };

    CSInterface.prototype.closeExtension = function () {
        window.__adobe_cep__.closeExtension();
    };

    CSInterface.prototype.requestOpenExtension = function (extensionId, params) {
        window.__adobe_cep__.requestOpenExtension(extensionId, params);
    };

    CSInterface.prototype.getExtensions = function (extensionIds) {
        var extensionIdsStr = JSON.stringify(extensionIds);
        var extensionsStr = window.__adobe_cep__.getExtensions(extensionIdsStr);
        return JSON.parse(extensionsStr);
    };

    CSInterface.prototype.initResourceBundle = function () {
        var resourceBundle = window.__adobe_cep__.initResourceBundle();
        return JSON.parse(resourceBundle);
    };

    CSInterface.prototype.dumpInstallationInfo = function () {
        return window.__adobe_cep__.dumpInstallationInfo();
    };

    CSInterface.prototype.getOSInformation = function () {
        return window.__adobe_cep__.getOSInformation();
    };

    CSInterface.prototype.updatePanelMenuItem = function (menuItemLabel, enabled, checked) {
        window.__adobe_cep__.updatePanelMenuItem(menuItemLabel, enabled, checked);
    };

    CSInterface.prototype.setPanelFlyoutMenu = function (menu) {
        window.__adobe_cep__.setPanelFlyoutMenu(menu);
    };

    CSInterface.prototype.updateFlyoutMenu = function (menu) {
        window.__adobe_cep__.updateFlyoutMenu(menu);
    };

    CSInterface.prototype.setContextMenu = function (menu, callback) {
        window.__adobe_cep__.setContextMenu(menu, callback);
    };

    CSInterface.prototype.setContextMenuByJSON = function (menu, callback) {
        window.__adobe_cep__.setContextMenuByJSON(menu, callback);
    };

    CSInterface.prototype.isWindowVisible = function () {
        return window.__adobe_cep__.isWindowVisible();
    };

    CSInterface.prototype.resizeContent = function (width, height) {
        window.__adobe_cep__.resizeContent(width, height);
    };

    CSInterface.prototype.registerInvalidCertificateCallback = function (callback) {
        return window.__adobe_cep__.registerInvalidCertificateCallback(callback);
    };

    CSInterface.prototype.registerKeyEventsInterest = function (keyEventsInterest) {
        window.__adobe_cep__.registerKeyEventsInterest(keyEventsInterest);
    };

    CSInterface.prototype.setWindowTitle = function (title) {
        window.__adobe_cep__.invokeSync("setWindowTitle", title);
    };

    CSInterface.prototype.getCurrentApiVersion = function () {
        return JSON.parse(window.__adobe_cep__.getCurrentApiVersion());
    };

    return CSInterface;
}));
