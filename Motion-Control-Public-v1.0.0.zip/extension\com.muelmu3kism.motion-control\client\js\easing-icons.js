/* Easing button visuals — Lucide primary + mini curve accent */
var EasingIcons = (function () {
    "use strict";

    function svgCurve(paths, size) {
        size = size || 18;
        return (
            '<svg xmlns="http://www.w3.org/2000/svg" width="' + size + '" height="' + size + '" ' +
            'viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="2.2" ' +
            'stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' +
            paths + "</svg>"
        );
    }

    var curves = {
        easy: '<path d="M4 26 C10 26, 12 8, 28 8"/>',
        in: '<path d="M4 26 C22 26, 24 8, 28 8"/>',
        out: '<path d="M4 26 C8 26, 10 8, 28 8"/>',
        hard: '<path d="M4 26 L16 14 L28 8"/>',
        snap: '<path d="M4 26 L12 24 L28 8"/><circle cx="28" cy="8" r="2" fill="currentColor" stroke="none"/>',
        linear: '<path d="M4 26 L28 8"/>',
        hold: '<path d="M4 26 L12 26 L12 8 L28 8"/>',
        overshoot: '<path d="M4 26 C12 26, 14 4, 22 12 S26 6, 28 8"/>',
        bounce: '<path d="M4 26 C10 26, 12 10, 18 18 C22 22, 24 12, 28 8"/>',
        spring: '<path d="M4 26 C9 26, 11 14, 16 20 C19 23, 22 12, 26 10 S28 8, 28 8"/>',
        antic: '<path d="M4 26 C6 28, 8 30, 12 24 C16 18, 20 10, 28 8"/>',
        anticSpring: '<path d="M4 26 C6 29, 9 31, 12 24 C15 16, 18 14, 20 18 C22 22, 24 14, 27 10 S29 8, 29 8"/>'
    };

    var lucideMap = {
        easy: "sparkles",
        in: "logIn",
        out: "logOut",
        hard: "zap",
        snap: "magnet",
        linear: "moveHorizontal",
        hold: "pause",
        overshoot: "trendingUp",
        bounce: "activity",
        spring: "waves",
        antic: "undo2",
        anticSpring: "gitMerge"
    };

    function mountAnticSpring(el, size) {
        size = size || 28;
        el.innerHTML = "";
        var row = document.createElement("span");
        row.className = "ease-lucide-dual";
        row.style.display = "flex";
        row.style.gap = "2px";
        row.style.alignItems = "center";
        var a = document.createElement("span");
        var b = document.createElement("span");
        LucideIcons.mount(a, "undo2", Math.round(size * 0.42));
        LucideIcons.mount(b, "waves", Math.round(size * 0.42));
        row.appendChild(a);
        row.appendChild(b);
        el.appendChild(row);
        var curveEl = document.createElement("span");
        curveEl.className = "ease-mini-curve";
        curveEl.innerHTML = svgCurve(curves.anticSpring, Math.round(size * 0.65));
        el.appendChild(curveEl);
    }

    function mount(el, name, size) {
        if (!el) return;
        if (name === "anticSpring") {
            mountAnticSpring(el, size);
            return;
        }
        if (!curves[name]) return;
        size = size || 28;

        var lucideEl = document.createElement("span");
        lucideEl.className = "ease-lucide";
        if (lucideMap[name] && typeof LucideIcons !== "undefined") {
            LucideIcons.mount(lucideEl, lucideMap[name], Math.round(size * 0.85));
        }

        var curveEl = document.createElement("span");
        curveEl.className = "ease-mini-curve";
        curveEl.innerHTML = svgCurve(curves[name], Math.round(size * 0.65));

        el.innerHTML = "";
        el.appendChild(lucideEl);
        el.appendChild(curveEl);
    }

    return { curves: curves, lucideMap: lucideMap, mount: mount };
}());
