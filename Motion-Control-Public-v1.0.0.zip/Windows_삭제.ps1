﻿$ErrorActionPreference = "Stop"
$id = "com.muelmu3kism.motion-control"
$destination = Join-Path $env:APPDATA "Adobe\CEP\extensions\$id"
if (Test-Path $destination) {
    Remove-Item -Recurse -Force $destination
    Write-Host "Motion Control 패널을 삭제했습니다." -ForegroundColor Green
} else {
    Write-Host "설치된 Motion Control 패널이 없습니다."
}
Write-Host "저장한 팔레트는 지우지 않았습니다."
Read-Host "Enter를 누르면 닫힙니다"