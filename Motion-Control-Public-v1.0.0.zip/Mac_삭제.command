#!/bin/bash
ID="com.muelmu3kism.motion-control"
DEST="$HOME/Library/Application Support/Adobe/CEP/extensions/$ID"
rm -rf "$DEST"
echo "Motion Control 패널을 삭제했습니다."
echo "저장한 팔레트는 지우지 않았습니다."
read -r