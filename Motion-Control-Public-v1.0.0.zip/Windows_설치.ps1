﻿$ErrorActionPreference = "Stop"
$id = "com.muelmu3kism.motion-control"
$source = Join-Path $PSScriptRoot "extension\$id"
$destinationRoot = Join-Path $env:APPDATA "Adobe\CEP\extensions"
$destination = Join-Path $destinationRoot $id

if (-not (Test-Path (Join-Path $source "CSXS\manifest.xml"))) {
    Write-Host "설치 파일을 찾지 못했습니다. ZIP을 먼저 완전히 풀어 주세요." -ForegroundColor Red
    Read-Host "Enter를 누르면 닫힙니다"
    exit 1
}

New-Item -ItemType Directory -Force -Path $destinationRoot | Out-Null
if (Test-Path $destination) {
    Remove-Item -Recurse -Force $destination
}
Copy-Item -Recurse -Force $source $destination
Set-Content -Path (Join-Path $destination ".debug") -Value "motion-control-public" -Encoding ASCII -NoNewline

foreach ($version in @("10", "11", "12")) {
    $key = "HKCU:\Software\Adobe\CSXS.$version"
    if (-not (Test-Path $key)) {
        New-Item -Path $key -Force | Out-Null
    }
    Set-ItemProperty -Path $key -Name "PlayerDebugMode" -Value "1" -Type String
}

$cache = Join-Path $env:LOCALAPPDATA "Temp\cep_cache"
if (Test-Path $cache) {
    Remove-Item -Recurse -Force $cache -ErrorAction SilentlyContinue
}

Write-Host ""
Write-Host "설치 완료!" -ForegroundColor Green
Write-Host "1. After Effects를 완전히 종료하세요."
Write-Host "2. After Effects를 다시 실행하세요."
Write-Host "3. 창 > 확장 기능(레거시) > Motion Control을 여세요."
Write-Host ""
Read-Host "Enter를 누르면 닫힙니다"