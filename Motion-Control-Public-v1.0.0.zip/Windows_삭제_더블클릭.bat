@echo off
chcp 65001 >nul
title Motion Control 삭제
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Windows_삭제.ps1"