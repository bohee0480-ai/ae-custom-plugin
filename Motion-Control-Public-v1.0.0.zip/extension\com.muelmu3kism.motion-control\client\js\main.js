/* Motion Control — CEP panel */
(function () {
    "use strict";

    var cs = new CSInterface();
    var panelExtPath = "";
    var state = {
        color: { h: 250, s: 0.72, v: 0.9 },
        colorTarget: "fill",
        hex: "#6C5CE7",
        fillHex: "#6C5CE7",
        strokeHex: "#FFFFFF",
        brushSize: 8,
        strokes: [],
        currentStroke: null,
        undoStack: [],
        grid: {
            cols: 5,
            rows: 5,
            cellSize: 80,
            gap: 12,
            cells: {},
            shape: "circle",
            fillEnabled: true,
            strokeEnabled: false,
            strokeWidth: 4
        },
        debugLines: [],
        activeTab: "main",
        palette: {
            palettes: [{ name: "my palette", colors: [] }],
            index: 0,
            selectedColor: -1,
            hydrated: false,
            dirty: false
        }
    };

    var els = {};

    function $(id) { return document.getElementById(id); }

    function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }

    function hsvToRgb(h, s, v) {
        var c = v * s;
        var x = c * (1 - Math.abs(((h / 60) % 2) - 1));
        var m = v - c;
        var r = 0, g = 0, b = 0;
        if (h < 60) { r = c; g = x; }
        else if (h < 120) { r = x; g = c; }
        else if (h < 180) { g = c; b = x; }
        else if (h < 240) { g = x; b = c; }
        else if (h < 300) { r = x; b = c; }
        else { r = c; b = x; }
        return [
            Math.round((r + m) * 255),
            Math.round((g + m) * 255),
            Math.round((b + m) * 255)
        ];
    }

    function rgbToHex(r, g, b) {
        function hex(n) {
            var s = n.toString(16);
            return s.length === 1 ? "0" + s : s;
        }
        return "#" + hex(r) + hex(g) + hex(b);
    }

    function hexToRgb255(hex) {
        var h = String(hex || "").replace("#", "");
        if (h.length === 3) {
            h = h.charAt(0) + h.charAt(0) + h.charAt(1) + h.charAt(1) + h.charAt(2) + h.charAt(2);
        }
        return [
            parseInt(h.substring(0, 2), 16) || 0,
            parseInt(h.substring(2, 4), 16) || 0,
            parseInt(h.substring(4, 6), 16) || 0
        ];
    }

    function rgbToHsv(r, g, b) {
        r /= 255;
        g /= 255;
        b /= 255;
        var max = Math.max(r, g, b);
        var min = Math.min(r, g, b);
        var d = max - min;
        var h = 0;
        var s = max === 0 ? 0 : d / max;
        var v = max;
        if (d > 0.00001) {
            if (max === r) h = 60 * (((g - b) / d) % 6);
            else if (max === g) h = 60 * ((b - r) / d + 2);
            else h = 60 * ((r - g) / d + 4);
        }
        if (h < 0) h += 360;
        return { h: h, s: s, v: v };
    }

    function setStatus(msg, isError) {
        els.statusLine.textContent = msg;
        els.statusLine.className = isError ? "status error" : "status";
    }

    function formatHostError(data, label, raw) {
        var parts = [];
        parts.push(data.error || data.message || "Unknown error");
        if (data.stage || label) parts.push("stage=" + (data.stage || label));
        if (data.file) parts.push("file=" + data.file);
        if (data.line !== undefined && data.line !== null) parts.push("line=" + data.line);
        if (data.scriptPath) parts.push("script=" + data.scriptPath);
        if (data.comp) parts.push("comp=" + data.comp);
        if (data.grid) parts.push("grid=" + data.grid);
        if (data.cellsRequested !== undefined) parts.push("cells=" + data.cellsRequested);
        if (data.detail) parts.push(String(data.detail));
        if (raw && (!data.ok) && raw.indexOf("{") !== 0) parts.push("raw=" + raw);
        return parts.join(" | ");
    }

    function appendDebug(text) {
        var ts = new Date().toLocaleTimeString();
        state.debugLines.unshift("[" + ts + "] " + text);
        if (state.debugLines.length > 40) state.debugLines.length = 40;
        if (els.debugLog) els.debugLog.textContent = state.debugLines.join("\n");
    }

    function isHostLoadFailure(raw) {
        var s = String(raw == null ? "" : raw);
        if (!s || s === "undefined") return true;
        if (s === "EvalScript error.") return true;
        if (s.indexOf("EvalScript error") !== -1) return true;
        return false;
    }

    function hostLoadFailMessage(raw) {
        var quoted = raw ? String(raw) : "EvalScript error.";
        return 'host 로드 실패 "' + quoted + '"';
    }

    function handleHostResult(label, raw, onOk) {
        if (isHostLoadFailure(raw)) {
            var bridgeMsg = hostLoadFailMessage(raw);
            appendDebug("ERR " + bridgeMsg + " | stage=" + label);
            setStatus(bridgeMsg, true);
            return;
        }

        var data = parseHost(raw);
        if (!data.ok) {
            var errMsg = formatHostError(data, label, raw);
            appendDebug("ERR " + errMsg);
            setStatus(errMsg, true);
            return;
        }

        appendDebug("OK " + label + ": " + (data.message || JSON.stringify(data)));
        if (label !== "savePalettes") {
            setStatus(data.message || label + " OK", false);
        }
        if (onOk) onOk(data);
    }

    function normalizeExtPath(p) {
        p = String(p || "");
        p = p.replace(/^file:\/{2,3}/, "");
        return p.replace(/\\/g, "/");
    }

    function safeExtensionPath() {
        try {
            return normalizeExtPath(cs.getSystemPath("extension"));
        } catch (e) {
            appendDebug("WARN getSystemPath failed: " + e.message);
            return "";
        }
    }

    function testHostBridge() {
        cs.evalScript("typeof applyPanelEasing", function (res) {
            if (res === "function") {
                appendDebug("Bridge OK: applyPanelEasing loaded");
            } else {
                appendDebug("ERR Bridge: applyPanelEasing=" + String(res));
                setStatus(hostLoadFailMessage(res || "EvalScript error."), true);
            }
        });
    }

    function evalHost(label, fn, arg, cb, arg2, arg3) {
        var script;
        if (arg instanceof Array) {
            var parts = [];
            var ai;
            for (ai = 0; ai < arg.length; ai++) {
                parts.push(JSON.stringify(arg[ai]));
            }
            script = fn + "(" + parts.join(",") + ")";
        } else if (arg === undefined || arg === null) {
            script = fn + "()";
        } else if (typeof arg === "string" && arg3 !== undefined) {
            script = fn + "(" + JSON.stringify(arg) + "," + JSON.stringify(arg2) + "," + JSON.stringify(arg3) + ")";
        } else if (typeof arg === "string" && arg2 !== undefined) {
            script = fn + "(" + JSON.stringify(arg) + "," + JSON.stringify(arg2) + ")";
        } else if (typeof arg === "string") {
            script = fn + "(" + JSON.stringify(arg) + ")";
        } else {
            script = fn + "(" + JSON.stringify(JSON.stringify(arg)) + ")";
        }
        appendDebug("CALL " + label + " -> " + script);
        cs.evalScript(script, function (res) {
            handleHostResult(label, res, cb);
        });
    }

    function parseHost(res) {
        try { return JSON.parse(res); } catch (e) { return { ok: false, error: String(res) }; }
    }

    /* ---- Path simplify ---- */
    function distSq(a, b) {
        var dx = a[0] - b[0];
        var dy = a[1] - b[1];
        return dx * dx + dy * dy;
    }

    function perpDist(point, lineStart, lineEnd) {
        var dx = lineEnd[0] - lineStart[0];
        var dy = lineEnd[1] - lineStart[1];
        if (dx === 0 && dy === 0) return Math.sqrt(distSq(point, lineStart));
        var t = ((point[0] - lineStart[0]) * dx + (point[1] - lineStart[1]) * dy) / (dx * dx + dy * dy);
        t = clamp(t, 0, 1);
        var px = lineStart[0] + t * dx;
        var py = lineStart[1] + t * dy;
        return Math.sqrt(distSq(point, [px, py]));
    }

    function simplifyRDP(points, tolerance) {
        if (points.length <= 2) return points.slice();
        var maxDist = 0;
        var index = 0;
        var end = points.length - 1;
        var i;
        for (i = 1; i < end; i++) {
            var d = perpDist(points[i], points[0], points[end]);
            if (d > maxDist) { maxDist = d; index = i; }
        }
        if (maxDist > tolerance) {
            var left = simplifyRDP(points.slice(0, index + 1), tolerance);
            var right = simplifyRDP(points.slice(index), tolerance);
            return left.slice(0, left.length - 1).concat(right);
        }
        return [points[0], points[end]];
    }

    function simplifyStroke(points) {
        if (points.length < 3) return points.slice();
        return simplifyRDP(points, 1.8);
    }

    /* ---- Color wheel ---- */
    function activeColorHex() {
        return state.colorTarget === "stroke" ? state.strokeHex : state.fillHex;
    }

    function applyHexToWheel(hex) {
        var rgb = hexToRgb255(hex);
        var hsv = rgbToHsv(rgb[0], rgb[1], rgb[2]);
        state.color.h = hsv.h;
        state.color.s = hsv.s;
        state.color.v = hsv.v;
        state.hex = hex;
        if (els.brightnessSlider) {
            els.brightnessSlider.value = String(Math.round(hsv.v * 100));
        }
    }

    function updateColorSwatches() {
        var fillOn = state.grid.fillEnabled;
        var strokeOn = state.grid.strokeEnabled;
        var fillActive = state.colorTarget === "fill";
        if (els.fillSwatch) els.fillSwatch.style.background = state.fillHex;
        if (els.strokeSwatch) els.strokeSwatch.style.background = state.strokeHex;
        if (els.colorTargetFill) els.colorTargetFill.classList.toggle("active", fillActive);
        if (els.colorTargetStroke) els.colorTargetStroke.classList.toggle("active", !fillActive);
        if (els.gridFillSwatch) {
            els.gridFillSwatch.style.background = state.fillHex;
            els.gridFillSwatch.classList.toggle("active", fillActive);
            els.gridFillSwatch.classList.toggle("is-off", !fillOn);
        }
        if (els.gridStrokeSwatch) {
            els.gridStrokeSwatch.style.background = state.strokeHex;
            els.gridStrokeSwatch.classList.toggle("active", !fillActive);
            els.gridStrokeSwatch.classList.toggle("is-off", !strokeOn);
        }
    }

    function setColorTarget(target) {
        state.colorTarget = target === "stroke" ? "stroke" : "fill";
        var hex = activeColorHex();
        applyHexToWheel(hex);
        drawColorWheel();
        updateColorSwatches();
        updateGridCellPreview();
        if (els.activeHexLabel) els.activeHexLabel.textContent = hex;
    }
    function applyHexToActiveTarget(hex) {
        applyHexToWheel(hex);
        if (state.colorTarget === "stroke") state.strokeHex = hex;
        else state.fillHex = hex;
        drawColorWheel();
        updateColorSwatches();
        updateGridCellPreview();
        if (els.activeHexLabel) els.activeHexLabel.textContent = hex;
    }

    function normalizePaletteHexClient(hex) {
        var text = String(hex || "").replace(/^\s+|\s+$/g, "").replace(/^#/, "");
        if (text.length === 3) {
            text = text.charAt(0) + text.charAt(0) + text.charAt(1) + text.charAt(1) + text.charAt(2) + text.charAt(2);
        }
        if (!/^[0-9a-fA-F]{6}$/.test(text)) return null;
        return "#" + text.toUpperCase();
    }

    function ensurePaletteArrays(palettes) {
        var i;
        if (!palettes || !palettes.length) {
            return [{ name: "my palette", colors: [] }];
        }
        for (i = 0; i < palettes.length; i++) {
            if (!palettes[i].colors || !(palettes[i].colors instanceof Array)) {
                palettes[i].colors = [];
            }
        }
        return palettes;
    }

    function markPaletteDirty() {
        state.palette.dirty = true;
    }

    function paletteActionReady() {
        if (!state.palette.hydrated) {
            setStatus("팔레트 불러오는 중… 잠시 후 다시 시도", true);
            return false;
        }
        return true;
    }

    function applyLoadedPalettes(palettes, force) {
        var prevIndex = state.palette.index;
        var prevSelected = state.palette.selectedColor;
        var prevName = "";
        var palBefore = currentPalette();
        if (palBefore) prevName = palBefore.name;
        if (force || !state.palette.dirty) {
            state.palette.palettes = ensurePaletteArrays(palettes);
            var byName = prevName ? findPaletteIndexByName(prevName) : -1;
            if (byName >= 0) {
                state.palette.index = byName;
            } else if (prevIndex >= 0 && prevIndex < state.palette.palettes.length) {
                state.palette.index = prevIndex;
            } else {
                state.palette.index = 0;
            }
            var pal = currentPalette();
            if (pal && prevSelected >= 0 && prevSelected < pal.colors.length) {
                state.palette.selectedColor = prevSelected;
            } else if (pal && pal.colors.length) {
                state.palette.selectedColor = pal.colors.length - 1;
            } else {
                state.palette.selectedColor = -1;
            }
        }
        state.palette.hydrated = true;
        refreshPaletteUI();
    }

    var paletteSaveBusy = false;
    var paletteSaveQueuedMessage = null;
    var paletteSaveQueuedDone = null;

    function reloadPalettesFromHost(done) {
        evalHost("loadPalettes", "loadColorPalettes", null, function (dataPal) {
            if (dataPal && dataPal.palettes && dataPal.palettes.length) {
                applyLoadedPalettes(dataPal.palettes, true);
            } else {
                state.palette.hydrated = true;
                refreshPaletteUI();
            }
            if (done) done(dataPal);
        });
    }

    function flushPersistPalettes(message, onDone) {
        paletteSaveBusy = true;
        evalHost("savePalettes", "saveColorPalettes", JSON.stringify(state.palette.palettes), function (data) {
            reloadPalettesFromHost(function () {
                paletteSaveBusy = false;
                if (message) setStatus(message, false);
                if (onDone) onDone(data);
                if (paletteSaveQueuedMessage !== null || paletteSaveQueuedDone) {
                    var nextMsg = paletteSaveQueuedMessage;
                    var nextDone = paletteSaveQueuedDone;
                    paletteSaveQueuedMessage = null;
                    paletteSaveQueuedDone = null;
                    flushPersistPalettes(nextMsg, nextDone);
                }
            });
        });
    }

    function persistPalettes(message, onDone) {
        markPaletteDirty();
        if (paletteSaveBusy) {
            paletteSaveQueuedMessage = message;
            paletteSaveQueuedDone = onDone || null;
            return;
        }
        flushPersistPalettes(message, onDone);
    }

    function currentPalette() {
        var list = state.palette.palettes;
        var idx = state.palette.index;
        if (!list || !list.length) return null;
        if (idx < 0 || idx >= list.length) return list[0];
        return list[idx];
    }

    function cleanPaletteName(name) {
        return String(name || "").replace(/^\s+|\s+$/g, "").replace(/[\t\r\n]+/g, " ");
    }

    function findPaletteIndexByName(name) {
        var target = cleanPaletteName(name).toLowerCase();
        var i;
        for (i = 0; i < state.palette.palettes.length; i++) {
            if (String(state.palette.palettes[i].name || "").toLowerCase() === target) return i;
        }
        return -1;
    }

    function renderPaletteSelect() {
        var sel = els.paletteSelect;
        var i;
        if (!sel) return;
        sel.innerHTML = "";
        for (i = 0; i < state.palette.palettes.length; i++) {
            var opt = document.createElement("option");
            opt.value = String(i);
            opt.textContent = state.palette.palettes[i].name;
            if (i === state.palette.index) opt.selected = true;
            sel.appendChild(opt);
        }
        var pal = currentPalette();
        if (els.paletteName) els.paletteName.value = pal ? pal.name : "my palette";
    }

    function renderPaletteSwatches() {
        var host = els.paletteSwatches;
        var pal = currentPalette();
        var i;
        if (!host) return;
        host.innerHTML = "";
        if (!pal || !pal.colors.length) {
            var empty = document.createElement("p");
            empty.className = "palette-empty";
            empty.textContent = "휠에서 색을 고른 뒤 Add";
            host.appendChild(empty);
            return;
        }
        if (state.palette.selectedColor >= pal.colors.length) {
            state.palette.selectedColor = pal.colors.length - 1;
        }
        for (i = 0; i < pal.colors.length; i++) {
            (function (index) {
                var btn = document.createElement("button");
                btn.type = "button";
                btn.className = "palette-chip" + (index === state.palette.selectedColor ? " selected" : "");
                btn.style.background = pal.colors[index];
                btn.title = pal.colors[index];
                btn.addEventListener("click", function () {
                    state.palette.selectedColor = index;
                    applyHexToActiveTarget(pal.colors[index]);
                    renderPaletteSwatches();
                    setStatus("Selected " + pal.colors[index] + " → " + state.colorTarget, false);
                });
                host.appendChild(btn);
            })(i);
        }
    }

    function refreshPaletteUI() {
        renderPaletteSelect();
        renderPaletteSwatches();
    }

    function nextPaletteName() {
        var n = 2;
        while (findPaletteIndexByName("palette " + n) >= 0) n++;
        return "palette " + n;
    }

    function requirePaletteColor() {
        var pal = currentPalette();
        if (!pal || state.palette.selectedColor < 0 || state.palette.selectedColor >= pal.colors.length) {
            setStatus("Select a palette color first", true);
            return false;
        }
        return true;
    }

    function runPaletteApply(mode) {
        var pal = currentPalette();
        if (!pal || !pal.colors.length) {
            setStatus("Add colors first", true);
            return;
        }
        if (mode === "selected" && !requirePaletteColor()) return;
        if (!panelExtPath) panelExtPath = safeExtensionPath();
        evalHost("paletteApply:" + mode, "applyPanelColorPalette", [
            JSON.stringify({
                mode: mode,
                colors: pal.colors.slice(0),
                selectedIndex: state.palette.selectedColor
            }),
            panelExtPath || ""
        ]);
    }

    function initPalette() {
        if (!els.paletteSelect) return;

        els.paletteSelect.addEventListener("change", function () {
            state.palette.index = Number(this.value) || 0;
            state.palette.selectedColor = -1;
            refreshPaletteUI();
        });

        els.btnPaletteNew.addEventListener("click", function () {
            if (!paletteActionReady()) return;
            var name = nextPaletteName();
            state.palette.palettes.push({ name: name, colors: [] });
            state.palette.index = state.palette.palettes.length - 1;
            state.palette.selectedColor = -1;
            refreshPaletteUI();
            persistPalettes("New palette '" + name + "'");
        });

        els.btnPaletteDelete.addEventListener("click", function () {
            if (!paletteActionReady()) return;
            var pal = currentPalette();
            var name;
            var nextIndex;
            if (!pal) return;
            name = pal.name;
            state.palette.palettes.splice(state.palette.index, 1);
            if (!state.palette.palettes.length) {
                state.palette.palettes.push({ name: "my palette", colors: [] });
                nextIndex = 0;
            } else {
                nextIndex = state.palette.index;
                if (nextIndex >= state.palette.palettes.length) nextIndex = state.palette.palettes.length - 1;
            }
            state.palette.index = nextIndex;
            state.palette.selectedColor = -1;
            refreshPaletteUI();
            persistPalettes("Deleted '" + name + "'");
        });

        els.btnPaletteRename.addEventListener("click", function () {
            if (!paletteActionReady()) return;
            var pal = currentPalette();
            var name = cleanPaletteName(els.paletteName.value);
            var existing;
            if (!pal) return;
            if (!name) {
                setStatus("Enter a palette name", true);
                return;
            }
            if (pal.name.toLowerCase() === "my palette" && name.toLowerCase() !== "my palette") {
                els.paletteName.value = pal.name;
                setStatus("Use Save to create a named palette", true);
                return;
            }
            if (name.toLowerCase() === "my palette" && pal.name.toLowerCase() !== "my palette") {
                els.paletteName.value = pal.name;
                setStatus("'my palette' is reserved", true);
                return;
            }
            existing = findPaletteIndexByName(name);
            if (existing >= 0 && existing !== state.palette.index) {
                setStatus("That palette name already exists", true);
                return;
            }
            pal.name = name;
            refreshPaletteUI();
            persistPalettes("Renamed to '" + name + "'");
        });

        els.btnPaletteSave.addEventListener("click", function () {
            if (!paletteActionReady()) return;
            var pal = currentPalette();
            var name = cleanPaletteName(els.paletteName.value);
            var existing;
            if (!pal) return;
            if (!name) {
                setStatus("Enter a palette name", true);
                return;
            }
            if (!pal.colors.length) {
                setStatus("Add colors first, then Save", true);
                return;
            }
            if (name.toLowerCase() === "my palette") {
                persistPalettes("Saved 'my palette'");
                return;
            }
            existing = findPaletteIndexByName(name);
            if (existing >= 0) {
                state.palette.palettes[existing].colors = pal.colors.slice(0);
                state.palette.index = existing;
                refreshPaletteUI();
                persistPalettes("Updated '" + name + "'");
                return;
            }
            state.palette.palettes.push({ name: name, colors: pal.colors.slice(0) });
            state.palette.index = state.palette.palettes.length - 1;
            refreshPaletteUI();
            persistPalettes("Saved '" + name + "'");
        });

        els.btnPaletteAdd.addEventListener("click", function () {
            if (!paletteActionReady()) return;
            var pal = currentPalette();
            var hex = normalizePaletteHexClient(activeColorHex());
            if (!pal) return;
            if (!hex) {
                setStatus("유효한 색상이 아닙니다: " + activeColorHex(), true);
                return;
            }
            pal.colors.push(hex);
            state.palette.selectedColor = pal.colors.length - 1;
            refreshPaletteUI();
            persistPalettes("Added " + hex + " to '" + pal.name + "'");
        });

        els.btnPaletteReplace.addEventListener("click", function () {
            if (!paletteActionReady()) return;
            var pal = currentPalette();
            var hex = normalizePaletteHexClient(activeColorHex());
            if (!pal || !requirePaletteColor()) return;
            if (!hex) {
                setStatus("유효한 색상이 아닙니다: " + activeColorHex(), true);
                return;
            }
            pal.colors[state.palette.selectedColor] = hex;
            refreshPaletteUI();
            persistPalettes("Replaced with " + hex);
        });

        els.btnPaletteRemove.addEventListener("click", function () {
            if (!paletteActionReady()) return;
            var pal = currentPalette();
            var removed;
            if (!pal || !requirePaletteColor()) return;
            removed = pal.colors[state.palette.selectedColor];
            pal.colors.splice(state.palette.selectedColor, 1);
            if (state.palette.selectedColor >= pal.colors.length) {
                state.palette.selectedColor = pal.colors.length - 1;
            }
            refreshPaletteUI();
            persistPalettes("Removed " + removed);
        });

        els.btnPaletteUp.addEventListener("click", function () {
            if (!paletteActionReady()) return;
            var pal = currentPalette();
            var idx;
            var swap;
            if (!pal || !requirePaletteColor()) return;
            idx = state.palette.selectedColor;
            if (idx <= 0) {
                setStatus("Already at the top", true);
                return;
            }
            swap = pal.colors[idx - 1];
            pal.colors[idx - 1] = pal.colors[idx];
            pal.colors[idx] = swap;
            state.palette.selectedColor = idx - 1;
            refreshPaletteUI();
            persistPalettes("Moved up");
        });

        els.btnPaletteDown.addEventListener("click", function () {
            if (!paletteActionReady()) return;
            var pal = currentPalette();
            var idx;
            var swap;
            if (!pal || !requirePaletteColor()) return;
            idx = state.palette.selectedColor;
            if (idx >= pal.colors.length - 1) {
                setStatus("Already at the bottom", true);
                return;
            }
            swap = pal.colors[idx + 1];
            pal.colors[idx + 1] = pal.colors[idx];
            pal.colors[idx] = swap;
            state.palette.selectedColor = idx + 1;
            refreshPaletteUI();
            persistPalettes("Moved down");
        });

        els.btnPaletteRandom.addEventListener("click", function () { runPaletteApply("random"); });
        els.btnPaletteAreaRank.addEventListener("click", function () { runPaletteApply("areaRank"); });
        els.btnPaletteApplySel.addEventListener("click", function () { runPaletteApply("selected"); });
        els.btnPaletteCapture.addEventListener("click", function () {
            if (!paletteActionReady()) return;
            var pal = currentPalette();
            var existing = {};
            var i;
            var added = 0;
            var hex;
            if (!pal) return;
            if (!panelExtPath) panelExtPath = safeExtensionPath();
            evalHost("paletteCapture", "capturePanelColorPalette", panelExtPath || "", function (data) {
                if (!data || !data.colors || !data.colors.length) {
                    setStatus(data && data.message ? data.message : "캡처할 색이 없습니다", true);
                    return;
                }
                for (i = 0; i < pal.colors.length; i++) {
                    existing[normalizePaletteHexClient(pal.colors[i]) || pal.colors[i]] = true;
                }
                for (i = 0; i < data.colors.length; i++) {
                    hex = normalizePaletteHexClient(data.colors[i]);
                    if (!hex || existing[hex]) continue;
                    pal.colors.push(hex);
                    existing[hex] = true;
                    added++;
                }
                state.palette.selectedColor = pal.colors.length ? pal.colors.length - 1 : -1;
                refreshPaletteUI();
                if (added < 1) {
                    setStatus("이미 팔레트에 있는 색입니다 (" + data.colors.length + " chips)", false);
                    return;
                }
                persistPalettes(
                    "캡처 " + data.colors.length + "색 · " + added + "개 추가 → '" + pal.name + "'"
                );
            });
        });

        refreshPaletteUI();
    }

    function updateColorFromHsv() {
        var rgb = hsvToRgb(state.color.h, state.color.s, state.color.v);
        state.hex = rgbToHex(rgb[0], rgb[1], rgb[2]);
        if (state.colorTarget === "stroke") state.strokeHex = state.hex;
        else state.fillHex = state.hex;
        drawColorWheel();
        updateColorSwatches();
        updateGridCellPreview();
    }

    function updateGridCellPreview() {
        if (!els.cellBoard) return;
        var g = state.grid;
        var board = els.cellBoard;
        var dense = board.classList.contains("cell-board-dense");
        board.className = "cell-board shape-" + g.shape + (dense ? " cell-board-dense" : "");
        var styleClass = "style-both";
        if (g.fillEnabled && !g.strokeEnabled) styleClass = "style-fill";
        else if (!g.fillEnabled && g.strokeEnabled) styleClass = "style-stroke";
        else if (!g.fillEnabled && !g.strokeEnabled) styleClass = "style-none";
        board.classList.add(styleClass);
        if (board.style) {
            board.style.setProperty("--cell-fill", state.fillHex);
            board.style.setProperty("--cell-stroke", state.strokeHex);
            board.style.setProperty("--cell-stroke-w", String(g.strokeWidth) + "px");
        }
    }

    function setGridShape(shape) {
        state.grid.shape = shape;
        var btns = els.gridShapePicker.querySelectorAll(".shape-btn");
        var i;
        for (i = 0; i < btns.length; i++) {
            btns[i].classList.toggle("active", btns[i].getAttribute("data-shape") === shape);
        }
        updateGridCellPreview();
    }

    function syncGridStyleUI() {
        var g = state.grid;
        els.gridFillOn.checked = g.fillEnabled;
        els.gridStrokeOn.checked = g.strokeEnabled;
        els.gridStrokeWidth.value = String(g.strokeWidth);
        els.gridStrokeWidthLabel.textContent = g.strokeWidth + "px";
        els.gridStrokeWidthRow.hidden = !g.strokeEnabled;
        updateColorSwatches();
        updateGridCellPreview();
    }

    function drawColorWheel() {
        var canvas = els.colorWheel;
        var ctx = canvas.getContext("2d");
        var w = canvas.width;
        var cx = w / 2;
        var cy = w / 2;
        var radius = w / 2 - 2;
        ctx.clearRect(0, 0, w, w);
        var angle;
        for (angle = 0; angle < 360; angle++) {
            var start = (angle - 1) * Math.PI / 180;
            var end = angle * Math.PI / 180;
            ctx.beginPath();
            ctx.moveTo(cx, cy);
            ctx.arc(cx, cy, radius, start, end);
            ctx.closePath();
            var rgb = hsvToRgb(angle, 1, 1);
            ctx.fillStyle = "rgb(" + rgb.join(",") + ")";
            ctx.fill();
        }
        ctx.beginPath();
        ctx.arc(cx, cy, radius * 0.28, 0, Math.PI * 2);
        ctx.fillStyle = "#2d2d2d";
        ctx.fill();
        var markerAngle = state.color.h * Math.PI / 180;
        var mr = radius * state.color.s;
        ctx.beginPath();
        ctx.arc(cx + Math.cos(markerAngle) * mr, cy + Math.sin(markerAngle) * mr, 5, 0, Math.PI * 2);
        ctx.strokeStyle = "#fff";
        ctx.lineWidth = 2;
        ctx.stroke();
    }

    function pickColorFromWheel(ev) {
        var rect = els.colorWheel.getBoundingClientRect();
        var x = (ev.clientX - rect.left) * (els.colorWheel.width / rect.width);
        var y = (ev.clientY - rect.top) * (els.colorWheel.height / rect.height);
        var cx = els.colorWheel.width / 2;
        var cy = els.colorWheel.height / 2;
        var dx = x - cx;
        var dy = y - cy;
        var dist = Math.sqrt(dx * dx + dy * dy);
        var maxR = cx - 2;
        if (dist > maxR) { dx *= maxR / dist; dy *= maxR / dist; dist = maxR; }
        var angle = Math.atan2(dy, dx) * 180 / Math.PI;
        if (angle < 0) angle += 360;
        state.color.h = angle;
        state.color.s = clamp(dist / maxR, 0, 1);
        updateColorFromHsv();
    }

    /* ---- Canvas drawing ---- */
    function redrawCanvas() {
        var canvas = els.drawCanvas;
        var ctx = canvas.getContext("2d");
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.fillStyle = "#141414";
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.lineCap = "round";
        ctx.lineJoin = "round";
        var i, s, pts;
        for (i = 0; i < state.strokes.length; i++) {
            s = state.strokes[i];
            pts = s.points;
            if (pts.length < 2) continue;
            ctx.beginPath();
            ctx.strokeStyle = s.color || state.hex;
            ctx.lineWidth = s.width || state.brushSize;
            ctx.moveTo(pts[0][0], pts[0][1]);
            var p;
            for (p = 1; p < pts.length; p++) ctx.lineTo(pts[p][0], pts[p][1]);
            ctx.stroke();
        }
        if (state.currentStroke && state.currentStroke.points.length > 1) {
            pts = state.currentStroke.points;
            ctx.beginPath();
            ctx.strokeStyle = state.currentStroke.color;
            ctx.lineWidth = state.currentStroke.width;
            ctx.moveTo(pts[0][0], pts[0][1]);
            for (p = 1; p < pts.length; p++) ctx.lineTo(pts[p][0], pts[p][1]);
            ctx.stroke();
        }
    }

    function pushUndo() {
        state.undoStack.push(JSON.stringify(state.strokes));
        if (state.undoStack.length > 40) state.undoStack.shift();
    }

    function initDrawCanvas() {
        var canvas = els.drawCanvas;
        var drawing = false;

        function getPos(ev) {
            var rect = canvas.getBoundingClientRect();
            return [
                (ev.clientX - rect.left) * (canvas.width / rect.width),
                (ev.clientY - rect.top) * (canvas.height / rect.height)
            ];
        }

        function beginStroke(ev) {
            drawing = true;
            pushUndo();
            state.currentStroke = {
                points: [getPos(ev)],
                color: state.hex,
                width: state.brushSize
            };
        }

        function moveStroke(ev) {
            if (!drawing || !state.currentStroke) return;
            var pt = getPos(ev);
            var pts = state.currentStroke.points;
            var last = pts[pts.length - 1];
            if (distSq(pt, last) < 1.5) return;
            pts.push(pt);
            redrawCanvas();
        }

        function endStroke() {
            if (!drawing) return;
            drawing = false;
            if (state.currentStroke && state.currentStroke.points.length > 1) {
                state.strokes.push(state.currentStroke);
            }
            state.currentStroke = null;
            redrawCanvas();
        }

        canvas.addEventListener("mousedown", beginStroke);
        canvas.addEventListener("mousemove", moveStroke);
        window.addEventListener("mouseup", endStroke);

        els.btnClearCanvas.addEventListener("click", function () {
            if (state.strokes.length === 0) return;
            pushUndo();
            state.strokes = [];
            state.currentStroke = null;
            redrawCanvas();
            setStatus("Canvas cleared");
        });

        els.btnUndo.addEventListener("click", function () {
            if (state.undoStack.length === 0) return;
            state.strokes = JSON.parse(state.undoStack.pop());
            state.currentStroke = null;
            redrawCanvas();
            setStatus("Undo");
        });

        redrawCanvas();
    }

    function setBrushSize(v) {
        state.brushSize = clamp(Math.round(v), 1, 40);
        els.brushSlider.value = String(state.brushSize);
        els.brushLabel.textContent = state.brushSize + "px";
    }

    /* ---- AE actions ---- */
    function createShapeLayer() {
        if (state.strokes.length === 0) {
            setStatus("Draw a stroke first");
            return;
        }
        var payload = {
            canvasW: els.drawCanvas.width,
            canvasH: els.drawCanvas.height,
            strokeColor: state.hex,
            strokeWidth: state.brushSize,
            layerName: "Pencil " + (state.strokes.length > 1 ? "Drawing" : "Stroke"),
            strokes: state.strokes.map(function (s) {
                return { points: simplifyStroke(s.points), width: s.width };
            })
        };
        setStatus("Creating shape layer…", false);
        evalHost("createPencilShape", "createPencilShapeLayer", JSON.stringify(payload), function (data) {
            setStatus("Created: " + data.layerName + " (" + data.paths + " path(s))", false);
        });
    }

    function applyEasing(type) {
        panelExtPath = panelExtPath || safeExtensionPath();
        evalHost("easing:" + type, "applyPanelEasing", [type, "{}", panelExtPath], function (data) {
            setStatus(data.message || (type + " applied"), false);
        });
    }

    var EASING_FEATURED = { id: "easy", label: "기본", tipResult: "모든 키에 기본 이지 인/아웃" };

    var EASING_BUTTONS = [
        { id: "in", label: "감속", tipResult: "모든 키에 감속(ease in) 적용" },
        { id: "out", label: "가속", tipResult: "모든 키에 가속(ease out) 적용" },
        { id: "hard", label: "각짐", tipResult: "모든 키에 각진 이징 적용" },
        { id: "snap", label: "스냅", tipResult: "모든 키에 스냅 이징 적용" },
        { id: "linear", label: "직선", tipResult: "모든 키를 직선 보간으로" },
        { id: "hold", label: "홀드", tipResult: "모든 키를 홀드 보간으로" },
        { id: "overshoot", label: "오버", tipResult: "모든 키에 오버슈트 텐션" },
        { id: "bounce", label: "바운스", tipResult: "모든 키에 바운스 텐션" },
        { id: "spring", label: "스프링", tipResult: "모든 키에 스프링 텐션" },
        { id: "antic", label: "반동", tipResult: "모든 키에 반동(antic) 텐션" },
        { id: "anticSpring", label: "탄성", tipResult: "모든 키에 탄성 스프링 텐션" }
    ];

    function createEaseButton(item, featured) {
        var btn = document.createElement("button");
        btn.type = "button";
        btn.className = featured ? "ease-btn-featured" : "ease-btn-80";
        btn.removeAttribute("title");
        btn.setAttribute("data-tip-need", "활성 컴프 · 키프레임이 있으면 됨 (선택 불필요)");
        btn.setAttribute("data-tip-result", item.tipResult || (item.label + " 이징을 모든 키에 적용"));
        btn.setAttribute("data-ease", item.id);

        var curve = document.createElement("span");
        curve.className = "ease-curve";
        EasingIcons.mount(curve, item.id, featured ? 36 : 28);

        var label = document.createElement("span");
        label.className = "ease-name";
        label.textContent = item.label;

        btn.appendChild(curve);
        btn.appendChild(label);
        btn.addEventListener("click", function () {
            applyEasing(item.id);
        });
        return btn;
    }

    function initEasingGrid() {
        els.easingFeatured.innerHTML = "";
        els.easingGrid.innerHTML = "";
        els.easingFeatured.appendChild(createEaseButton(EASING_FEATURED, true));

        var i;
        for (i = 0; i < EASING_BUTTONS.length; i++) {
            els.easingGrid.appendChild(createEaseButton(EASING_BUTTONS[i], false));
        }
    }

    /* ---- Grid cell board ---- */
    var GRID_MIN_DIM = 2;
    var GRID_MAX_DIM = 100;

    function gridShapeLabel(shape) {
        if (shape === "circle") return "원";
        if (shape === "rectangle") return "네모";
        if (shape === "roundRect") return "라운드";
        if (shape === "triangle") return "세모";
        if (shape === "star") return "별";
        if (shape === "random") return "랜덤";
        return shape;
    }

    function cellKey(row, col) {
        return row + ":" + col;
    }

    function gridDims() {
        var cols = clamp(Math.round(Number(els.gridCols.value) || 5), GRID_MIN_DIM, GRID_MAX_DIM);
        var rows = clamp(Math.round(Number(els.gridRows.value) || 5), GRID_MIN_DIM, GRID_MAX_DIM);
        els.gridCols.value = String(cols);
        els.gridRows.value = String(rows);
        state.grid.cols = cols;
        state.grid.rows = rows;
        return { cols: cols, rows: rows };
    }

    function countSelectedCells() {
        var n = 0;
        var k;
        for (k in state.grid.cells) {
            if (state.grid.cells[k]) n++;
        }
        return n;
    }

    function updateCellCountLabel() {
        var n = countSelectedCells();
        els.cellCountLabel.textContent = n + " selected";
    }

    function computeCellBoardMetrics(cols, rows) {
        var total = cols * rows;
        var maxDim = Math.max(cols, rows);
        var cellPx;
        var headPx;
        var insetPx;
        var dense = total > 400;
        var huge = total > 2500;

        if (huge) {
            cellPx = 4;
            headPx = 10;
            insetPx = 1;
        } else if (dense) {
            cellPx = Math.max(5, Math.min(12, Math.floor(260 / maxDim)));
            headPx = Math.max(10, Math.min(14, cellPx + 1));
            insetPx = Math.max(1, Math.round(cellPx * 0.2));
        } else {
            cellPx = Math.max(6, Math.min(28, Math.floor(280 / maxDim)));
            headPx = Math.max(14, Math.min(18, cellPx));
            insetPx = Math.max(3, Math.round(cellPx * 0.22));
        }

        return {
            total: total,
            cellPx: cellPx,
            headPx: headPx,
            insetPx: insetPx,
            dense: dense,
            huge: huge
        };
    }

    function updateCellBoardHint(metrics) {
        if (!els.cellHint) return;
        if (metrics.huge) {
            els.cellHint.textContent = metrics.total + " cells — scroll · drag to select · Select All for full grid";
        } else if (metrics.dense) {
            els.cellHint.textContent = "Scroll to navigate · drag to select area · Shift+drag to add";
        } else {
            els.cellHint.textContent = "Drag to select area · Shift+drag to add · Click to toggle";
        }
    }

    function renderCellBoard() {
        var dim = gridDims();
        var cols = dim.cols;
        var rows = dim.rows;
        var board = els.cellBoard;
        var wrap = els.cellBoardWrap;
        var metrics = computeCellBoardMetrics(cols, rows);
        var nextCells = {};
        var r, c, key;
        var frag;
        var cellPx = metrics.cellPx;
        var headPx = metrics.headPx;
        var insetPx = metrics.insetPx;

        for (key in state.grid.cells) {
            if (!state.grid.cells[key]) continue;
            var parts = key.split(":");
            r = Number(parts[0]);
            c = Number(parts[1]);
            if (r >= 1 && r <= rows && c >= 1 && c <= cols) {
                nextCells[key] = true;
            }
        }
        state.grid.cells = nextCells;

        board.innerHTML = "";
        board.className = "cell-board shape-" + state.grid.shape + (metrics.dense ? " cell-board-dense" : "");
        board.style.gap = metrics.dense ? "1px" : "3px";
        board.style.gridTemplateColumns = headPx + "px repeat(" + cols + ", " + cellPx + "px)";
        board.style.gridTemplateRows = headPx + "px repeat(" + rows + ", " + cellPx + "px)";
        board.style.setProperty("--cell-inset", insetPx + "px");

        if (wrap) {
            wrap.classList.toggle("is-dense", metrics.dense);
            wrap.classList.toggle("is-huge", metrics.huge);
        }
        updateCellBoardHint(metrics);

        frag = document.createDocumentFragment();

        var corner = document.createElement("div");
        corner.className = "corner";
        corner.style.width = headPx + "px";
        corner.style.height = headPx + "px";
        frag.appendChild(corner);

        for (c = 1; c <= cols; c++) {
            var colHead = document.createElement("div");
            colHead.className = "col-head";
            colHead.style.height = headPx + "px";
            colHead.textContent = String(c);
            frag.appendChild(colHead);
        }

        for (r = 1; r <= rows; r++) {
            var rowHead = document.createElement("div");
            rowHead.className = "row-head";
            rowHead.style.width = headPx + "px";
            rowHead.textContent = String(r);
            frag.appendChild(rowHead);

            for (c = 1; c <= cols; c++) {
                key = cellKey(r, c);
                var btn = document.createElement("button");
                btn.type = "button";
                btn.className = "cell-btn" + (state.grid.cells[key] ? " on" : "");
                btn.setAttribute("data-row", String(r));
                btn.setAttribute("data-col", String(c));
                btn.title = "r" + r + " c" + c;
                btn.style.width = cellPx + "px";
                btn.style.height = cellPx + "px";
                frag.appendChild(btn);
            }
        }

        board.appendChild(frag);
        updateCellCountLabel();
        updateGridCellPreview();
    }

    function toggleCell(row, col, forceOn) {
        var key = cellKey(row, col);
        var next = forceOn !== undefined ? forceOn : !state.grid.cells[key];
        if (next) state.grid.cells[key] = true;
        else delete state.grid.cells[key];
        var btn = els.cellBoard.querySelector(
            '.cell-btn[data-row="' + row + '"][data-col="' + col + '"]'
        );
        if (btn) btn.classList.toggle("on", !!next);
        updateCellCountLabel();
    }

    function selectAllCells(on) {
        var dim = gridDims();
        var r, c;
        var expected = dim.cols * dim.rows;
        var existing = els.cellBoard.querySelectorAll(".cell-btn").length;
        state.grid.cells = {};
        if (on) {
            for (r = 1; r <= dim.rows; r++) {
                for (c = 1; c <= dim.cols; c++) {
                    state.grid.cells[cellKey(r, c)] = true;
                }
            }
        }
        if (existing === expected && expected > 0) {
            syncCellButtonStates();
            updateCellCountLabel();
        } else {
            renderCellBoard();
        }
    }

    function getSelectedCellList() {
        var list = [];
        var key, parts;
        for (key in state.grid.cells) {
            if (!state.grid.cells[key]) continue;
            parts = key.split(":");
            list.push({ row: Number(parts[0]), col: Number(parts[1]) });
        }
        list.sort(function (a, b) {
            if (a.row !== b.row) return a.row - b.row;
            return a.col - b.col;
        });
        return list;
    }

    function createGridCircles() {
        var cells = getSelectedCellList();
        if (cells.length === 0) {
            setStatus("Select cells on the grid board");
            return;
        }
        var payload = {
            cols: state.grid.cols,
            rows: state.grid.rows,
            cellSize: state.grid.cellSize,
            gap: state.grid.gap,
            fillColor: state.fillHex,
            strokeColor: state.strokeHex,
            shape: state.grid.shape,
            fillEnabled: state.grid.fillEnabled,
            strokeEnabled: state.grid.strokeEnabled,
            strokeWidth: state.grid.strokeWidth,
            cells: cells
        };
        if (!payload.fillEnabled && !payload.strokeEnabled) {
            setStatus("Enable Fill and/or Stroke", true);
            return;
        }
        setStatus("Creating " + cells.length + " " + gridShapeLabel(state.grid.shape) + " shape(s)…", false);
        if (!panelExtPath) {
            panelExtPath = safeExtensionPath();
        }
        evalHost("gridCircles", "createGridCircles", [JSON.stringify(payload), panelExtPath], function (data) {
            setStatus(data.message || ("Created " + data.count + " shapes"), false);
        });
    }

    function syncCellButtonStates() {
        var btns = els.cellBoard.querySelectorAll(".cell-btn");
        var i;
        for (i = 0; i < btns.length; i++) {
            var btn = btns[i];
            var row = Number(btn.getAttribute("data-row"));
            var col = Number(btn.getAttribute("data-col"));
            btn.classList.toggle("on", !!state.grid.cells[cellKey(row, col)]);
        }
        updateCellCountLabel();
    }

    function clearDragPreview() {
        var btns = els.cellBoard.querySelectorAll(".cell-btn.preview-on");
        var i;
        for (i = 0; i < btns.length; i++) btns[i].classList.remove("preview-on");
    }

    function rectBounds(r1, c1, r2, c2) {
        return {
            minR: Math.min(r1, r2),
            maxR: Math.max(r1, r2),
            minC: Math.min(c1, c2),
            maxC: Math.max(c1, c2)
        };
    }

    function isInRect(row, col, bounds) {
        return row >= bounds.minR && row <= bounds.maxR &&
            col >= bounds.minC && col <= bounds.maxC;
    }

    function updateDragPreview(bounds) {
        var btns = els.cellBoard.querySelectorAll(".cell-btn");
        var i;
        for (i = 0; i < btns.length; i++) {
            var btn = btns[i];
            var row = Number(btn.getAttribute("data-row"));
            var col = Number(btn.getAttribute("data-col"));
            btn.classList.toggle("preview-on", isInRect(row, col, bounds));
        }
    }

    function applyRectSelection(bounds, additive) {
        var next = {};
        var key;
        if (additive) {
            for (key in state.grid.cells) {
                if (state.grid.cells[key]) next[key] = true;
            }
        }
        var r, c;
        for (r = bounds.minR; r <= bounds.maxR; r++) {
            for (c = bounds.minC; c <= bounds.maxC; c++) {
                next[cellKey(r, c)] = true;
            }
        }
        state.grid.cells = next;
        syncCellButtonStates();
    }

    function cellBtnFromPoint(x, y) {
        var el = document.elementFromPoint(x, y);
        while (el && el !== els.cellBoard) {
            if (el.classList && el.classList.contains("cell-btn")) return el;
            el = el.parentElement;
        }
        return null;
    }

    function initGridBoard() {
        var drag = {
            active: false,
            moved: false,
            additive: false,
            startRow: 1,
            startCol: 1,
            curRow: 1,
            curCol: 1,
            startX: 0,
            startY: 0,
            pointerId: null
        };

        renderCellBoard();

        function endDrag(ev) {
            if (!drag.active) return;
            drag.active = false;
            clearDragPreview();

            if (drag.moved) {
                applyRectSelection(
                    rectBounds(drag.startRow, drag.startCol, drag.curRow, drag.curCol),
                    drag.additive
                );
            } else {
                toggleCell(drag.startRow, drag.startCol);
            }

            if (drag.pointerId !== null) {
                try { els.cellBoard.releasePointerCapture(drag.pointerId); } catch (eCap) {}
            }
            drag.pointerId = null;
        }

        els.cellBoard.addEventListener("pointerdown", function (ev) {
            var btn = ev.target.classList.contains("cell-btn")
                ? ev.target
                : cellBtnFromPoint(ev.clientX, ev.clientY);
            if (!btn) return;

            ev.preventDefault();
            drag.active = true;
            drag.moved = false;
            drag.additive = ev.shiftKey;
            drag.startRow = drag.curRow = Number(btn.getAttribute("data-row"));
            drag.startCol = drag.curCol = Number(btn.getAttribute("data-col"));
            drag.startX = ev.clientX;
            drag.startY = ev.clientY;
            drag.pointerId = ev.pointerId;

            try { els.cellBoard.setPointerCapture(ev.pointerId); } catch (eCap2) {}

            updateDragPreview(rectBounds(drag.startRow, drag.startCol, drag.curRow, drag.curCol));
        });

        els.cellBoard.addEventListener("pointermove", function (ev) {
            if (!drag.active) return;

            var btn = cellBtnFromPoint(ev.clientX, ev.clientY);
            if (btn) {
                drag.curRow = Number(btn.getAttribute("data-row"));
                drag.curCol = Number(btn.getAttribute("data-col"));
            }

            if (Math.abs(ev.clientX - drag.startX) > 3 || Math.abs(ev.clientY - drag.startY) > 3) {
                drag.moved = true;
            }

            updateDragPreview(rectBounds(drag.startRow, drag.startCol, drag.curRow, drag.curCol));
        });

        els.cellBoard.addEventListener("pointerup", endDrag);
        els.cellBoard.addEventListener("pointercancel", endDrag);

        function nudgeDim(field, delta) {
            var el = field === "cols" ? els.gridCols : els.gridRows;
            el.value = String(clamp(Number(el.value) + delta, GRID_MIN_DIM, GRID_MAX_DIM));
            renderCellBoard();
        }

        els.btnColsDown.addEventListener("click", function () { nudgeDim("cols", -1); });
        els.btnColsUp.addEventListener("click", function () { nudgeDim("cols", 1); });
        els.btnRowsDown.addEventListener("click", function () { nudgeDim("rows", -1); });
        els.btnRowsUp.addEventListener("click", function () { nudgeDim("rows", 1); });
        els.gridCols.addEventListener("change", renderCellBoard);
        els.gridRows.addEventListener("change", renderCellBoard);

        els.btnGridSelectAll.addEventListener("click", function () { selectAllCells(true); });
        els.btnGridClear.addEventListener("click", function () { selectAllCells(false); });

        els.gridCellSize.addEventListener("input", function () {
            state.grid.cellSize = Number(this.value);
            els.gridCellSizeLabel.textContent = state.grid.cellSize + "px";
        });
        els.gridGap.addEventListener("input", function () {
            state.grid.gap = Number(this.value);
            els.gridGapLabel.textContent = state.grid.gap + "px";
        });

        els.btnCreateGrid.addEventListener("click", createGridCircles);

        els.gridShapePicker.addEventListener("click", function (ev) {
            var btn = ev.target.closest(".shape-btn");
            if (!btn) return;
            setGridShape(btn.getAttribute("data-shape"));
        });

        els.gridFillOn.addEventListener("change", function () {
            state.grid.fillEnabled = this.checked;
            if (!state.grid.fillEnabled && !state.grid.strokeEnabled) {
                state.grid.strokeEnabled = true;
            }
            if (state.grid.fillEnabled) setColorTarget("fill");
            else setColorTarget("stroke");
            syncGridStyleUI();
        });

        els.gridStrokeOn.addEventListener("change", function () {
            state.grid.strokeEnabled = this.checked;
            if (!state.grid.fillEnabled && !state.grid.strokeEnabled) {
                state.grid.fillEnabled = true;
            }
            if (state.grid.strokeEnabled) setColorTarget("stroke");
            else setColorTarget("fill");
            syncGridStyleUI();
        });

        if (els.gridFillSwatch) {
            els.gridFillSwatch.addEventListener("click", function () { setColorTarget("fill"); });
        }
        if (els.gridStrokeSwatch) {
            els.gridStrokeSwatch.addEventListener("click", function () { setColorTarget("stroke"); });
        }

        els.gridStrokeWidth.addEventListener("input", function () {
            state.grid.strokeWidth = Number(this.value);
            els.gridStrokeWidthLabel.textContent = state.grid.strokeWidth + "px";
            updateGridCellPreview();
        });

        syncGridStyleUI();
    }

    function setActiveTab(tabId) {
        state.activeTab = tabId || "main";
        var btns = document.querySelectorAll(".tab-btn");
        var panes = document.querySelectorAll(".tab-pane");
        var i;
        for (i = 0; i < btns.length; i++) {
            btns[i].classList.toggle("active", btns[i].getAttribute("data-tab") === state.activeTab);
        }
        for (i = 0; i < panes.length; i++) {
            panes[i].classList.toggle("active", panes[i].getAttribute("data-tab") === state.activeTab);
            panes[i].classList.remove("is-empty");
        }
        refreshVisibleTools();
    }

    function featureHaystack(el) {
        var parts = [el.getAttribute("data-search") || ""];
        var nodes = el.querySelectorAll("h2, summary, button, .ease-name, .easing-hint, .layout-hint, .path-hint, .timing-hint, .color-grid-note, .field-label");
        var i;
        for (i = 0; i < nodes.length; i++) {
            parts.push(nodes[i].textContent || "");
            if (nodes[i].title) parts.push(nodes[i].title);
        }
        return parts.join(" ").toLowerCase().replace(/\s+/g, " ");
    }

    function markSearchHits(el, q) {
        var nodes = el.querySelectorAll("button, .style-chip, .color-target");
        var i, text, hit;
        for (i = 0; i < nodes.length; i++) {
            text = ((nodes[i].textContent || "") + " " + (nodes[i].title || "")).toLowerCase();
            hit = !!q && text.indexOf(q) >= 0;
            nodes[i].classList.toggle("search-hit", hit);
        }
    }

    function refreshVisibleTools() {
        var colorCard = document.querySelector("[data-feature='color']");
        var pencilCard = document.querySelector("[data-feature='pencil']");
        var gridCard = document.querySelector("[data-feature='grid']");
        var searching = document.getElementById("app").classList.contains("is-searching");
        function shown(el) {
            if (!el || el.classList.contains("is-hidden")) return false;
            if (searching) return true;
            var pane = el.closest(".tab-pane");
            return pane && pane.classList.contains("active");
        }
        if (shown(colorCard)) {
            drawColorWheel();
            updateColorSwatches();
        }
        if (shown(pencilCard)) redrawCanvas();
        if (shown(gridCard)) updateGridCellPreview();
    }

    function applyFeatureSearch(raw) {
        var q = String(raw || "").toLowerCase().replace(/\s+/g, " ").trim();
        var app = document.getElementById("app");
        var blocks = document.querySelectorAll("[data-feature]");
        var panes = document.querySelectorAll(".tab-pane");
        var chips = document.querySelectorAll(".suggest-chip");
        var i, shown, paneShown, hay, match;

        if (els.featureSearch && els.featureSearch.value !== raw) {
            /* keep input as typed */
        }
        if (els.btnSearchClear) els.btnSearchClear.hidden = !q;

        for (i = 0; i < chips.length; i++) {
            chips[i].classList.toggle("active", !!q && chips[i].getAttribute("data-query") === q);
        }

        if (!q) {
            app.classList.remove("is-searching");
            for (i = 0; i < blocks.length; i++) {
                blocks[i].classList.remove("is-hidden");
                markSearchHits(blocks[i], "");
            }
            for (i = 0; i < panes.length; i++) panes[i].classList.remove("is-empty");
            if (els.searchEmpty) els.searchEmpty.hidden = true;
            setActiveTab(state.activeTab || "main");
            return;
        }

        app.classList.add("is-searching");
        shown = 0;
        for (i = 0; i < blocks.length; i++) {
            hay = featureHaystack(blocks[i]);
            match = hay.indexOf(q) >= 0;
            blocks[i].classList.toggle("is-hidden", !match);
            markSearchHits(blocks[i], q);
            if (match) shown++;
        }
        for (i = 0; i < panes.length; i++) {
            paneShown = panes[i].querySelectorAll("[data-feature]:not(.is-hidden)").length;
            panes[i].classList.toggle("is-empty", paneShown === 0);
        }
        if (els.searchEmpty) els.searchEmpty.hidden = shown > 0;
        refreshVisibleTools();
    }

    function clearFeatureSearch() {
        if (els.featureSearch) els.featureSearch.value = "";
        applyFeatureSearch("");
    }

    function initSearch() {
        if (!els.featureSearch) return;
        els.featureSearch.addEventListener("input", function () {
            applyFeatureSearch(this.value);
        });
        els.featureSearch.addEventListener("keydown", function (ev) {
            if (ev.key === "Escape" || ev.keyCode === 27) {
                clearFeatureSearch();
                els.featureSearch.blur();
            }
        });
        if (els.btnSearchClear) {
            els.btnSearchClear.addEventListener("click", clearFeatureSearch);
        }
        if (els.searchSuggest) {
            els.searchSuggest.addEventListener("click", function (ev) {
                var chip = ev.target.closest(".suggest-chip");
                if (!chip) return;
                var q = chip.getAttribute("data-query") || "";
                if (els.featureSearch.value === q) {
                    clearFeatureSearch();
                    return;
                }
                els.featureSearch.value = q;
                applyFeatureSearch(q);
            });
        }
    }

    function initTabs() {
        if (!els.panelTabs) return;
        els.panelTabs.addEventListener("click", function (ev) {
            var btn = ev.target.closest(".tab-btn");
            if (!btn) return;
            clearFeatureSearch();
            setActiveTab(btn.getAttribute("data-tab"));
        });
    }

    function initIcons() {
        LucideIcons.mount($("searchIcon"), "search", 14);
        LucideIcons.mount($("btnSearchClear"), "x", 12);
        LucideIcons.mount($("btnUndo"), "undo2", 16);
        LucideIcons.mount($("btnClearCanvas"), "trash2", 16);
        LucideIcons.mount($("btnBrushDown"), "minus", 14);
        LucideIcons.mount($("btnBrushUp"), "plus", 14);
        LucideIcons.mount($("createShapeIcon"), "layers", 16);
        LucideIcons.mount($("btnGridSelectAll"), "checkSquare", 16);
        LucideIcons.mount($("btnGridClear"), "square", 16);
        LucideIcons.mount($("btnColsDown"), "minus", 12);
        LucideIcons.mount($("btnColsUp"), "plus", 12);
        LucideIcons.mount($("btnRowsDown"), "minus", 12);
        LucideIcons.mount($("btnRowsUp"), "plus", 12);
        LucideIcons.mount($("createGridIcon"), "grid3x3", 16);
        LucideIcons.mount($("shapeIconCircle"), "circle", 18);
        LucideIcons.mount($("shapeIconRect"), "square", 18);
        LucideIcons.mount($("shapeIconRoundRect"), "squircle", 18);
        LucideIcons.mount($("shapeIconTriangle"), "triangle", 18);
        LucideIcons.mount($("shapeIconStar"), "star", 18);
        LucideIcons.mount($("shapeIconRandom"), "shuffle", 18);
        LucideIcons.mount($("layoutPushOutIcon"), "expand", 18);
        LucideIcons.mount($("layoutGatherIcon"), "shrink", 18);
        LucideIcons.mount($("pathArcIcon"), "cornerUpRight", 18);
        LucideIcons.mount($("pathOrthoIcon"), "moveHorizontal", 18);
        LucideIcons.mount($("pathSIcon"), "waves", 18);
        LucideIcons.mount($("pathMorphIcon"), "gitMerge", 18);
        LucideIcons.mount($("pathMorphAppendIcon"), "plus", 18);
        LucideIcons.mount($("pathDiagnoseIcon"), "scanSearch", 18);
        LucideIcons.mount($("pathABIcon"), "arrowRightLeft", 18);
        LucideIcons.mount($("pathPointStaggerIcon"), "gripVertical", 18);
        LucideIcons.mount($("pathOvershootIcon"), "repeat", 18);
        LucideIcons.mount($("pathTrimDrawIcon"), "penLine", 18);
        LucideIcons.mount($("pathLineSweepIcon"), "wind", 18);
        LucideIcons.mount($("pathTrimIcon"), "logIn", 18);
        LucideIcons.mount($("pathLineFlowIcon"), "sparkles", 18);
        LucideIcons.mount($("pathWireframeIcon"), "activity", 18);
        LucideIcons.mount($("pathExtendIcon"), "trendingUp", 18);
    }

    function initControls() {
        els.btnCreateShape.addEventListener("click", createShapeLayer);

        els.brushSlider.addEventListener("input", function () {
            setBrushSize(Number(this.value));
        });
        els.btnBrushDown.addEventListener("click", function () { setBrushSize(state.brushSize - 1); });
        els.btnBrushUp.addEventListener("click", function () { setBrushSize(state.brushSize + 1); });

        var wheelDrag = false;
        els.colorWheel.addEventListener("mousedown", function (ev) { wheelDrag = true; pickColorFromWheel(ev); });
        window.addEventListener("mousemove", function (ev) { if (wheelDrag) pickColorFromWheel(ev); });
        window.addEventListener("mouseup", function () { wheelDrag = false; });

        els.brightnessSlider.addEventListener("input", function () {
            state.color.v = this.value / 100;
            updateColorFromHsv();
        });

        if (els.colorTargetFill) {
            els.colorTargetFill.addEventListener("click", function () { setColorTarget("fill"); });
        }
        if (els.colorTargetStroke) {
            els.colorTargetStroke.addEventListener("click", function () { setColorTarget("stroke"); });
        }

        if (els.btnLayoutPushOut) {
            els.btnLayoutPushOut.addEventListener("click", function () {
                if (!panelExtPath) panelExtPath = safeExtensionPath();
                setStatus("화면 밖으로 이동 중…", false);
                evalHost("layoutPushOut", "applyLayoutPushOut", panelExtPath || "");
            });
        }
        if (els.btnLayoutGather) {
            els.btnLayoutGather.addEventListener("click", function () {
                if (!panelExtPath) panelExtPath = safeExtensionPath();
                setStatus("중앙으로 모으는 중…", false);
                evalHost("layoutGather", "applyLayoutGatherCenter", panelExtPath || "");
            });
        }
        if (els.btnPathArc) {
            els.btnPathArc.addEventListener("click", function () {
                if (!panelExtPath) panelExtPath = safeExtensionPath();
                setStatus("곡선 경로 적용 중…", false);
                evalHost("pathArc", "applyPathArc", panelExtPath || "");
            });
        }
        if (els.btnPathOrtho) {
            els.btnPathOrtho.addEventListener("click", function () {
                if (!panelExtPath) panelExtPath = safeExtensionPath();
                setStatus("직각 경로 적용 중…", false);
                evalHost("pathOrtho", "applyPathOrtho", panelExtPath || "");
            });
        }
        if (els.btnPathS) {
            els.btnPathS.addEventListener("click", function () {
                if (!panelExtPath) panelExtPath = safeExtensionPath();
                setStatus("S자 경로 적용 중…", false);
                evalHost("pathS", "applyPathSCurve", panelExtPath || "");
            });
        }

        function runShapePathTool(label, fn, statusMsg) {
            if (!panelExtPath) panelExtPath = safeExtensionPath();
            setStatus(statusMsg, false);
            evalHost(label, fn, panelExtPath || "");
        }

        function showPathDiagnose(data) {
            var box = els.pathDiagnoseResult;
            if (!box) return;
            if (!data || !data.ok) {
                box.textContent = (data && data.message) ? data.message : "Path를 선택하세요";
                return;
            }
            var lines = [];
            var i;
            if (data.paths && data.paths.length) {
                for (i = 0; i < data.paths.length; i++) {
                    var p = data.paths[i];
                    lines.push(
                        (i + 1) + ". " + p.layer + " / " + p.pathGroup + "\n   " +
                        p.typeLabel + " · " + p.verts + "점 · ≈" + p.length + "px" +
                        (p.hasTrim ? " · Trim" : "") +
                        (p.hasExpression ? " · Expr" : "")
                    );
                }
            } else {
                lines.push(data.message || "진단 완료");
            }
            box.textContent = lines.join("\n\n");
        }

        if (els.btnPathDiagnose) {
            els.btnPathDiagnose.addEventListener("click", function () {
                if (!panelExtPath) panelExtPath = safeExtensionPath();
                setStatus("Path 진단 중…", false);
                evalHost("pathDiagnose", "diagnoseSelectedPaths", panelExtPath || "", function (data) {
                    showPathDiagnose(data);
                    setStatus(data.message || (data.ok ? "진단 완료" : "진단 실패"), !data.ok);
                });
            });
        }
        if (els.btnPathAB) {
            els.btnPathAB.addEventListener("click", function () {
                runShapePathTool("pathAB", "applyPathAB", "A→B 키 생성 중…");
            });
        }
        if (els.btnPathMorph) {
            els.btnPathMorph.addEventListener("click", function () {
                runShapePathTool("pathMorph", "applyPathMorph", "패스 모프 적용 중…");
            });
        }
        if (els.btnPathMorphAppend) {
            els.btnPathMorphAppend.addEventListener("click", function () {
                runShapePathTool("pathMorphAppend", "applyPathMorphAppend", "모프 이어붙이는 중…");
            });
        }
        if (els.btnPathPointStagger) {
            els.btnPathPointStagger.addEventListener("click", function () {
                runShapePathTool("pathPointStagger", "applyPathPointStagger", "포인트 스태거 적용 중…");
            });
        }
        if (els.btnPathOvershoot) {
            els.btnPathOvershoot.addEventListener("click", function () {
                runShapePathTool("pathOvershoot", "applyPathOvershootReturn", "오버슛 왕복 적용 중…");
            });
        }
        if (els.btnPathTrimDraw) {
            els.btnPathTrimDraw.addEventListener("click", function () {
                runShapePathTool("pathTrimDraw", "applyPathTrimDraw", "트림 드로잉 적용 중…");
            });
        }
        if (els.btnPathLineSweep) {
            els.btnPathLineSweep.addEventListener("click", function () {
                runShapePathTool("pathLineSweep", "applyPathLineSweep", "라인 스윕 적용 중…");
            });
        }
        if (els.btnPathTrim) {
            els.btnPathTrim.addEventListener("click", function () {
                runShapePathTool("pathTrim", "applyPathTrim", "트림패스 적용 중…");
            });
        }
        if (els.btnPathLineFlow) {
            els.btnPathLineFlow.addEventListener("click", function () {
                runShapePathTool("pathLineFlow", "applyPathLineFlow", "패스 플로우 적용 중…");
            });
        }
        if (els.btnPathWireframe) {
            els.btnPathWireframe.addEventListener("click", function () {
                runShapePathTool("pathWireframe", "applyPathWireframe", "와이어프레임 적용 중…");
            });
        }
        if (els.btnPathExtend) {
            els.btnPathExtend.addEventListener("click", function () {
                runShapePathTool("pathExtend", "applyPathExtend", "패스 연장 중…");
            });
        }

        function applyStaggerTemplate(seconds, label) {
            if (!panelExtPath) panelExtPath = safeExtensionPath();
            setStatus(label + " 스태거 적용 중…", false);
            evalHost("stagger" + String(seconds).replace(".", ""), "applyStaggerTiming", [seconds, panelExtPath || ""]);
        }

        if (els.btnStagger0) {
            els.btnStagger0.addEventListener("click", function () { applyStaggerTemplate(0, "0초"); });
        }
        if (els.btnStagger05) {
            els.btnStagger05.addEventListener("click", function () { applyStaggerTemplate(0.5, "0.5초"); });
        }
        if (els.btnStagger1) {
            els.btnStagger1.addEventListener("click", function () { applyStaggerTemplate(1, "1초"); });
        }
        if (els.btnStagger15) {
            els.btnStagger15.addEventListener("click", function () { applyStaggerTemplate(1.5, "1.5초"); });
        }
    }

    var FEATURE_TIPS = {
        btnLayoutPushOut: {
            need: "레이어 1개 이상 선택",
            result: "현재 시간 위치를 화면 밖으로 이동"
        },
        btnLayoutGather: {
            need: "레이어 1개 이상 선택",
            result: "현재 시간 위치를 컴프 중앙으로 모음"
        },
        btnPathArc: {
            need: "레이어 1개 이상 선택",
            result: "Position을 곡선 경로로 바꿈"
        },
        btnPathOrtho: {
            need: "레이어 1개 이상 선택",
            result: "Position을 가로→세로 직각 경로로"
        },
        btnPathS: {
            need: "레이어 1개 이상 선택",
            result: "Position을 S자 곡선 경로로 바꿈"
        },
        btnStagger0: {
            need: "레이어 1개 이상 선택",
            result: "시작을 0초에 맞추고 inPoint 통일"
        },
        btnStagger05: {
            need: "레이어 1개 이상 선택",
            result: "0~0.5초 순차 스태거, inPoint 통일"
        },
        btnStagger1: {
            need: "레이어 1개 이상 선택",
            result: "0~1초 순차 스태거, inPoint 통일"
        },
        btnStagger15: {
            need: "레이어 1개 이상 선택",
            result: "0~1.5초 순차 스태거, inPoint 통일"
        },
        btnPathDiagnose: {
            need: "Path 속성 1개 이상 선택",
            result: "닫힘/열림 · 점 수 · 길이 · 키 · Trim/Expression 표시"
        },
        btnPathAB: {
            need: "Path 2개 선택 (레이어 선택도 가능)",
            result: "첫 Path에 A→B 2키 (1초 간격)"
        },
        btnPathMorph: {
            need: "Path 2개 이상 선택 (레이어 선택도 가능)",
            result: "첫 Path에 1초 간격 모프 키 생성"
        },
        btnPathMorphAppend: {
            need: "모프된 첫 Path + 추가 Path (레이어 선택도 가능)",
            result: "기존 키 뒤에 모프를 이어붙임"
        },
        btnPathPointStagger: {
            need: "키 2개 이상 Path 선택",
            result: "CTRL_PathMorph · 포인트별 순차 모프 Expression"
        },
        btnPathOvershoot: {
            need: "키 2개 이상 Path 선택",
            result: "A→B 오버슛 · Hold · A 복귀 Expression"
        },
        btnPathTrimDraw: {
            need: "Path 속성 선택",
            result: "Trim End 0→100 · 그리기만 (퇴장 없음)"
        },
        btnPathLineSweep: {
            need: "Path 속성 선택 (Path로 변환된 상태)",
            result: "진입 → 대기 → 퇴장 Trim 애니메이션"
        },
        btnPathTrim: {
            need: "Path 속성 선택",
            result: "선이 그려진 뒤 같은 방향으로 사라짐"
        },
        btnPathLineFlow: {
            need: "Path 속성 선택",
            result: "패스를 따라 흐르는 도형 생성"
        },
        btnPathWireframe: {
            need: "Path 속성 선택",
            result: "앵커·핸들·연결선 와이어프레임 생성"
        },
        btnPathExtend: {
            need: "열린 Path 속성 선택",
            result: "패스 양끝을 곡선으로 연장"
        },
        colorTargetFill: {
            need: "없음",
            result: "컬러 휠이 Fill 색을 편집"
        },
        colorTargetStroke: {
            need: "없음",
            result: "컬러 휠이 Stroke 색을 편집"
        },
        btnPaletteAdd: {
            need: "휠에 색이 선택된 상태",
            result: "현재 색을 팔레트에 추가"
        },
        btnPaletteReplace: {
            need: "팔레트 스와치 1개 선택",
            result: "선택한 스와치를 휠 색으로 교체"
        },
        btnPaletteRemove: {
            need: "팔레트 스와치 1개 선택",
            result: "선택한 색을 팔레트에서 삭제"
        },
        btnPaletteUp: {
            need: "팔레트 스와치 1개 선택",
            result: "선택한 색 순서를 위로"
        },
        btnPaletteDown: {
            need: "팔레트 스와치 1개 선택",
            result: "선택한 색 순서를 아래로"
        },
        btnPaletteNew: {
            need: "없음",
            result: "빈 팔레트를 새로 만듦"
        },
        btnPaletteDelete: {
            need: "팔레트 1개 선택",
            result: "현재 팔레트를 삭제"
        },
        btnPaletteRename: {
            need: "이름 입력",
            result: "현재 팔레트 이름 변경"
        },
        btnPaletteSave: {
            need: "없음",
            result: "현재 팔레트를 이름으로 저장"
        },
        btnPaletteRandom: {
            need: "Shape Layer 선택 + 팔레트 색",
            result: "선택한 도형에 팔레트 색 랜덤 적용"
        },
        btnPaletteAreaRank: {
            need: "Shape Layer 선택 + 팔레트 색",
            result: "면적 큰 순으로 팔레트 색 적용"
        },
        btnPaletteApplySel: {
            need: "Shape Layer + 스와치 선택",
            result: "선택한 색만 도형에 적용"
        },
        btnPaletteCapture: {
            need: "Shape Layer 1개 이상 선택",
            result: "Fill·Stroke 색을 추출해 현재 팔레트에 저장 (비슷한 색은 한 칩)"
        },
        btnCreateShape: {
            need: "캔버스에 선을 그린 상태",
            result: "그린 선을 Shape Layer로 생성"
        },
        btnUndo: {
            need: "캔버스에 선이 있는 상태",
            result: "마지막 선을 취소"
        },
        btnClearCanvas: {
            need: "캔버스에 선이 있는 상태",
            result: "캔버스 선을 모두 지움"
        },
        btnCreateGrid: {
            need: "셀 1개 이상 선택",
            result: "선택한 셀 위치에 도형 생성"
        },
        btnGridSelectAll: {
            need: "없음",
            result: "그리드 셀을 모두 선택"
        },
        btnGridClear: {
            need: "선택된 셀",
            result: "셀 선택을 모두 해제"
        },
        gridFillSwatch: {
            need: "Fill 체크",
            result: "그리드 Fill에 휠 색 사용"
        },
        gridStrokeSwatch: {
            need: "Stroke 체크",
            result: "그리드 Stroke에 휠 색 사용"
        }
    };

    var SHAPE_TIPS = {
        circle: { need: "없음", result: "그리드 도형을 원으로" },
        rectangle: { need: "없음", result: "그리드 도형을 네모로" },
        roundRect: { need: "없음", result: "그리드 도형을 라운드 네모로" },
        triangle: { need: "없음", result: "그리드 도형을 세모로" },
        star: { need: "없음", result: "그리드 도형을 별로" },
        random: { need: "없음", result: "셀마다 도형 종류를 섞음" }
    };

    function hideFeatureTip() {
        if (!els.featureTip) return;
        els.featureTip.classList.remove("is-on");
    }

    function placeFeatureTip(anchor) {
        var tip = els.featureTip;
        var rect;
        var x;
        var y;
        var tw;
        var th;
        if (!tip || !anchor) return;
        rect = anchor.getBoundingClientRect();
        tw = tip.offsetWidth || 220;
        th = tip.offsetHeight || 64;
        x = rect.left + rect.width / 2 - tw / 2;
        y = rect.top - th - 8;
        if (y < 6) y = rect.bottom + 8;
        if (y + th > window.innerHeight - 6) y = Math.max(6, rect.top - th - 8);
        x = Math.max(6, Math.min(x, window.innerWidth - tw - 6));
        tip.style.left = x + "px";
        tip.style.top = y + "px";
    }

    function showFeatureTip(anchor) {
        var need = anchor.getAttribute("data-tip-need");
        var result = anchor.getAttribute("data-tip-result");
        if (!els.featureTip || !need) return;
        els.featureTipNeed.textContent = need;
        els.featureTipResult.textContent = result || "";
        els.featureTip.classList.add("is-on");
        placeFeatureTip(anchor);
    }

    function setTipAttrs(el, need, result) {
        if (!el) return;
        el.removeAttribute("title");
        el.setAttribute("data-tip-need", need);
        el.setAttribute("data-tip-result", result);
    }

    function initFeatureTips() {
        var id;
        var tipTimer = null;
        var tipTarget = null;
        var shapeBtns;
        var si;
        var kind;
        var tip;

        for (id in FEATURE_TIPS) {
            if (!FEATURE_TIPS.hasOwnProperty(id)) continue;
            setTipAttrs($(id), FEATURE_TIPS[id].need, FEATURE_TIPS[id].result);
        }

        shapeBtns = document.querySelectorAll(".shape-btn");
        for (si = 0; si < shapeBtns.length; si++) {
            kind = shapeBtns[si].getAttribute("data-shape");
            tip = SHAPE_TIPS[kind];
            if (tip) setTipAttrs(shapeBtns[si], tip.need, tip.result);
        }

        document.addEventListener("mouseover", function (ev) {
            var btn = ev.target.closest("[data-tip-need]");
            if (!btn || btn === tipTarget) return;
            tipTarget = btn;
            if (tipTimer) clearTimeout(tipTimer);
            tipTimer = setTimeout(function () {
                if (tipTarget === btn) showFeatureTip(btn);
            }, 220);
        });

        document.addEventListener("mouseout", function (ev) {
            var btn = ev.target.closest("[data-tip-need]");
            var next = ev.relatedTarget && ev.relatedTarget.closest
                ? ev.relatedTarget.closest("[data-tip-need]")
                : null;
            if (!btn || next === btn) return;
            if (tipTarget === btn) {
                tipTarget = null;
                if (tipTimer) clearTimeout(tipTimer);
                hideFeatureTip();
            }
        });

        document.addEventListener("scroll", hideFeatureTip, true);
        window.addEventListener("blur", hideFeatureTip);
    }

    function cacheElements() {
        els = {
            drawCanvas: $("drawCanvas"),
            btnUndo: $("btnUndo"),
            btnClearCanvas: $("btnClearCanvas"),
            btnCreateShape: $("btnCreateShape"),
            brushSlider: $("brushSlider"),
            brushLabel: $("brushLabel"),
            btnBrushDown: $("btnBrushDown"),
            btnBrushUp: $("btnBrushUp"),
            colorWheel: $("colorWheel"),
            colorTargetFill: $("colorTargetFill"),
            colorTargetStroke: $("colorTargetStroke"),
            fillSwatch: $("fillSwatch"),
            strokeSwatch: $("strokeSwatch"),
            brightnessSlider: $("brightnessSlider"),
            statusLine: $("statusLine"),
            debugLog: $("debugLog"),
            easingFeatured: $("easingFeatured"),
            easingGrid: $("easingGrid"),
            cellBoardWrap: $("cellBoardWrap"),
            cellBoard: $("cellBoard"),
            cellCountLabel: $("cellCountLabel"),
            cellHint: $("cellHint"),
            gridCols: $("gridCols"),
            gridRows: $("gridRows"),
            btnColsDown: $("btnColsDown"),
            btnColsUp: $("btnColsUp"),
            btnRowsDown: $("btnRowsDown"),
            btnRowsUp: $("btnRowsUp"),
            btnGridSelectAll: $("btnGridSelectAll"),
            btnGridClear: $("btnGridClear"),
            gridCellSize: $("gridCellSize"),
            gridCellSizeLabel: $("gridCellSizeLabel"),
            gridGap: $("gridGap"),
            gridGapLabel: $("gridGapLabel"),
            btnCreateGrid: $("btnCreateGrid"),
            gridShapePicker: $("gridShapePicker"),
            gridFillOn: $("gridFillOn"),
            gridStrokeOn: $("gridStrokeOn"),
            gridFillSwatch: $("gridFillSwatch"),
            gridStrokeSwatch: $("gridStrokeSwatch"),
            gridStrokeWidth: $("gridStrokeWidth"),
            gridStrokeWidthLabel: $("gridStrokeWidthLabel"),
            gridStrokeWidthRow: $("gridStrokeWidthRow"),
            btnLayoutPushOut: $("btnLayoutPushOut"),
            btnLayoutGather: $("btnLayoutGather"),
            btnPathArc: $("btnPathArc"),
            btnPathOrtho: $("btnPathOrtho"),
            btnPathS: $("btnPathS"),
            btnPathDiagnose: $("btnPathDiagnose"),
            pathDiagnoseResult: $("pathDiagnoseResult"),
            btnPathAB: $("btnPathAB"),
            btnPathMorph: $("btnPathMorph"),
            btnPathMorphAppend: $("btnPathMorphAppend"),
            btnPathPointStagger: $("btnPathPointStagger"),
            btnPathOvershoot: $("btnPathOvershoot"),
            btnPathTrimDraw: $("btnPathTrimDraw"),
            btnPathLineSweep: $("btnPathLineSweep"),
            btnPathTrim: $("btnPathTrim"),
            btnPathLineFlow: $("btnPathLineFlow"),
            btnPathWireframe: $("btnPathWireframe"),
            btnPathExtend: $("btnPathExtend"),
            btnStagger0: $("btnStagger0"),
            btnStagger05: $("btnStagger05"),
            btnStagger1: $("btnStagger1"),
            btnStagger15: $("btnStagger15"),
            panelTabs: $("panelTabs"),
            featureSearch: $("featureSearch"),
            btnSearchClear: $("btnSearchClear"),
            searchSuggest: $("searchSuggest"),
            searchEmpty: $("searchEmpty"),
            activeHexLabel: $("activeHexLabel"),
            paletteSelect: $("paletteSelect"),
            paletteName: $("paletteName"),
            paletteSwatches: $("paletteSwatches"),
            btnPaletteNew: $("btnPaletteNew"),
            btnPaletteDelete: $("btnPaletteDelete"),
            btnPaletteRename: $("btnPaletteRename"),
            btnPaletteSave: $("btnPaletteSave"),
            btnPaletteAdd: $("btnPaletteAdd"),
            btnPaletteReplace: $("btnPaletteReplace"),
            btnPaletteRemove: $("btnPaletteRemove"),
            btnPaletteUp: $("btnPaletteUp"),
            btnPaletteDown: $("btnPaletteDown"),
            btnPaletteRandom: $("btnPaletteRandom"),
            btnPaletteAreaRank: $("btnPaletteAreaRank"),
            btnPaletteApplySel: $("btnPaletteApplySel"),
            btnPaletteCapture: $("btnPaletteCapture"),
            featureTip: $("featureTip"),
            featureTipNeed: $("featureTipNeed"),
            featureTipResult: $("featureTipResult")
        };
    }

    function bootPanel() {
        try {
            panelExtPath = safeExtensionPath();
            appendDebug("Extension path: " + (panelExtPath || "(unknown)"));
        } catch (eBoot) {
            appendDebug("ERR bootPanel: " + eBoot.message);
        }

        testHostBridge();
        evalHost("initPaths", "initPanelPaths", panelExtPath || "", function (data) {
            appendDebug(data.message || "Paths initialized");
            evalHost("easingSetup", "verifyEasingSetup", panelExtPath || "", function (data2) {
                appendDebug(data2.message || "Easing check done");
                evalHost("loadPalettes", "loadColorPalettes", null, function (dataPal) {
                    if (dataPal && dataPal.palettes && dataPal.palettes.length) {
                        applyLoadedPalettes(dataPal.palettes);
                    } else {
                        state.palette.hydrated = true;
                        refreshPaletteUI();
                    }
                    evalHost("ping", "getActiveCompInfo", null, function (data3) {
                        if (data3 && data3.name) {
                            appendDebug("Active comp: " + data3.name + " (" + data3.width + "x" + data3.height + ")");
                        }
                    });
                });
            });
        });
    }

    function initErrorWatch() {
        window.addEventListener("error", function (ev) {
            var msg = ev && ev.message ? ev.message : "JS error";
            appendDebug("ERR JS " + msg);
            if (isHostLoadFailure(msg)) {
                setStatus(hostLoadFailMessage(msg), true);
            } else {
                setStatus("화면 오류: " + msg, true);
            }
        });
        window.addEventListener("unhandledrejection", function (ev) {
            var reason = ev && ev.reason ? ev.reason : "promise";
            var msg = reason && reason.message ? reason.message : String(reason);
            appendDebug("ERR Promise " + msg);
            if (isHostLoadFailure(msg)) {
                setStatus(hostLoadFailMessage(msg), true);
            }
        });
    }

    function init() {
        try {
            cacheElements();
            initErrorWatch();
            initTabs();
            initSearch();
            initIcons();
            setBrushSize(8);
            updateColorFromHsv();
            initDrawCanvas();
            initGridBoard();
            initEasingGrid();
            initControls();
            initPalette();
            initFeatureTips();
            appendDebug("Panel ready");
            bootPanel();
        } catch (eInit) {
            var msg = eInit && eInit.message ? eInit.message : String(eInit);
            try { appendDebug("ERR init " + msg); } catch (eDbg) {}
            try { setStatus("화면 오류: " + msg, true); } catch (eSt) {}
        }
    }

    document.addEventListener("DOMContentLoaded", init);
}());
