@echo off
chcp 65001 >nul
title Motion Control 설치
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Windows_설치.ps1"